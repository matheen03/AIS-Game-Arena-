/* AI Game Arena · Al-Rowad International Schools · Cross Curricular Programme */
(() => {
"use strict";
const KEY = "ai-game-arena";
const mem = {};
const store = {
  get(k){ try{ const v = localStorage.getItem(k); return v==null ? (mem[k]??null) : JSON.parse(v); }catch(e){ return mem[k]??null; } },
  set(k,v){ mem[k]=v; try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
};
let lang;
/* ---------- i18n ---------- */
const T = {
 en:{
  dupTitle:"A game with this name is already in your class. Choose a different name.",badImage:"That picture can't be used. Choose a JPG or PNG photo.",locked:"Too many wrong codes. Admin access is paused for 10 minutes.",network:"Can't reach the arena right now. Check the internet and try again.",badCode:"The new code must be 4 to 12 digits.",noGame:"That game isn't in the gallery any more.",
  notConfigured:"The arena isn't connected to its database yet. Add the Supabase details to config.js.",loadError:"Can't load the games right now.",retry:"Try again",loading:"Loading games…",all:"All",removePic:"Remove picture",
  bonusNow:"Extra coins given so far: students +{s}, parents and visitors +{v}",changeCode:"Change admin code",newCode:"New code (4–12 digits)",saveCode:"Save new code",codeSaved:"Admin code changed",
  startFresh:"Start fresh",startFreshLead:"Removes every sign-up, investment and like. Games stay. Use this after a rehearsal.",clearBtn:"Clear all coins, likes and sign-ups",cleared:"All coins, likes and sign-ups cleared",
  footer:"Cross Curricular Programme · AIS Game Arena",
  tabProfile:"Profile",seeInvestors:"See who invested",investorsOf:"Investors in {g}",noInvestorsYet:"Nobody has invested in this game yet.",investorsLead:"{n} AI Coins invested. Biggest investors first.",
  checkTitle:"Before your game goes in the gallery",checkLead:"Tick each rule to confirm your game follows the AIS Game Arena rules.",checkGo:"Confirm and publish",
  me_rule1:"My thumbnail is appropriate and follows Islamic conduct.",me_rule2:"My game characters are appropriate and follow Islamic conduct.",me_rule3:"My gameplay is appropriate and follows Islamic conduct (no killing people, stealing, etc.).",me_rule4:"My game has an original name, not copied from an existing game.",
  rulesTitle:"AIS Game Arena rules",rulesShow:"Show rules",rulesHide:"Hide",
  rulesText:"As we prepare for the relaunch of the AIS Game Arena, kindly review and edit your game to make sure it has no inappropriate content (like GTA). Games must be appropriate and follow the Islamic conduct of the AIS Game Arena to qualify for the gallery. Avoid inappropriate thumbnails and the names of games that already exist. Thank you for your understanding and cooperation.",
  rule1:"Thumbnails are appropriate and follow Islamic conduct.",rule2:"Game characters are appropriate and follow Islamic conduct.",rule3:"Gameplay is appropriate and follows Islamic conduct (no killing people, stealing, etc.).",rule4:"Every game has an original name, not copied from an existing game.",
  minNote:"The smallest investment is {m} AI Coins.",minInvest:"You need to invest at least {m} AI Coins.",visitorsLocked:"Parents and visitors can invest when investing opens at the Parent-Teacher Meeting.",visitorsLockedShort:"Opens at the Parent-Teacher Meeting",
  myProfile:"My profile",profileTitle:"My profile",profileLead:"Your AI Coins, the games you invested in, and what your own game has earned.",profileSignIn:"Sign in to see your AI Coins and your investments.",signInBtn:"Sign in",
  startCoins:"Starting AI Coins",investedNow:"AI Coins invested now",earnedTotal:"Earned from my game",owed:"Someone took their investment out of your game after you spent those coins, so you owe {n} AI Coins. New investments in your game pay this back first.",
  portfolio:"My investments",portfolioLead:"Changed your mind? Withdraw an investment to get your AI Coins back. The withdrawal service fee is {f} AI Coins, which stay in the game.",withdraw:"Withdraw",keptFee:"Fee kept in game",
  myGames:"My games",myGamesLead:"When someone invests in your game, the AI Coins are shared equally between the students who made it.",gameHas:"{n} AI Coins from {i} investors",
  withdrawTitle:"Withdraw from {g}",youHaveIn:"You have {n} AI Coins in this game",withdrawExplain:"You get {b} AI Coins back. {f} AI Coins stay in the game as the withdrawal service fee.",withdrawGo:"Withdraw {b} AI Coins",withdrawn:"{b} AI Coins are back in your account",
  nothingToWithdraw:"Only the {f} AI Coin fee is left in this game, so there's nothing to withdraw.",rulesNeeded:"Tick all four rules to publish your game.",
  visitorsTitle:"Parents and visitors",visitorsOpenNow:"Parents and visitors can sign up and invest now.",visitorsLockedNow:"Locked. Parents and visitors can't sign up or invest until you open it.",lockVisitors:"Lock parents and visitors",openVisitors:"Open for parents and visitors",visitorsOpened:"Parents and visitors can now invest",visitorsLockedToast:"Parents and visitors are locked",
  stEarned:"AI Coins earned by game makers",stWithdrawals:"Withdrawals",
  startFresh:"Reset coins",startFreshLead:"Puts every account back to its starting AI Coins: removes all investments, earnings and extra coins given. Games, pictures, descriptions, sign-ups and likes stay.",resetCoinsBtn:"Reset all AI Coins",coinsReset:"All AI Coins are back to the start",clearAllLead:"Only if you need a completely fresh start: also removes every sign-up and like. Games stay.",clearBtn:"Clear coins, sign-ups and likes",
appName:"AIS Game Arena",brandRest:"Game Arena",tagline:"Al-Rowad International Schools · Grade 8 game exhibition",tabGallery:"Game Gallery",tabRankings:"Rankings",tabInvest:"Invest",tabUpload:"Upload Game",
  galleryTitle:"Game Gallery",galleryLead:"Play a game, tap the heart if you like it, then invest your AI Coins in your favourites.",searchPh:"Search game, student name or S-number",allClasses:"All classes",
  classN:"Class {c}",games:"{n} games",game1:"1 game",play:"Play",invest:"Invest",coins:"AI Coins",investors:"Investors",likes:"Likes",scan:"Scan to play",prev:"Previous",next:"Next",pageOf:"Page {p} of {n}",noGames:"No games match your search.",
  rankTitle:"The Top 10",rankLead:"Games ranked by AI Coins invested. The top 10 games, marked with a trophy, go on show at the exhibition.",celebrate:"Celebrate!",rank:"Rank",game:"Game",team:"Game company",exhibition:"Exhibition game",first:"1st place",second:"2nd place",third:"3rd place",waiting:"Waiting for the first investment",investorsN:"{n} investors",investor1:"1 investor",
  wallet:"You have {n} AI Coins",walletShort:"{n}",
  invTitle:"Invest",invLead:"Choose who you are. You get your AI Coins once, and they stay with your account when you come back. Students also earn AI Coins when others invest in their game.",student:"Student",studentSub:"Use your S-number",studentGet:"{n} AI Coins",visitor:"Parent or visitor",visitorSub:"Use your name and email",
  snum:"S-number",snumPh:"e.g. S123456",name:"Name",cls:"Class",findMe:"Type your S-number and your name appears.",notFound:"We can't find that S-number. Check it and try again.",notG8:"Only Grade 8 students can upload games.",found:"Found: {n} · {c}",
  startInvesting:"Start investing",welcomeBack:"Welcome back",newHere:"New here",haveAccount:"I have an account",firstName:"First name",surname:"Surname",email:"Email address",createAccount:"Create account",logIn:"Log in",
  emailTaken:"This email already has an account. Choose “I have an account” to log in.",noEmail:"We can't find an account with that email. Choose “New here” to create one.",badEmail:"Enter a full email address, like name@example.com.",needName:"Enter your first name and surname.",
  youHave:"You have",coinsLeft:"AI Coins left to invest",myInv:"Your investments",noInv:"You haven't invested yet. Open the Game Gallery and pick a game you like.",goGallery:"Go to the Game Gallery",signOut:"Sign out",
  invModal:"Invest in {g}",howMany:"How many AI Coins?",confirmInv:"Invest {n} AI Coins",ownGame:"This is your own game, so you can't invest in it. Try another game!",notEnough:"You only have {n} AI Coins left.",invested:"You invested {n} AI Coins in {g}",signInFirst:"Choose Student or Parent first, then you can invest.",wholeNumber:"Enter a whole number of AI Coins.",
  upTitle:"Upload your game",upLead:"Fill in your details and your Netlify link. Your game card appears in the Game Gallery straight away.",s1:"Your S-number",s2:"Teammate's S-number",teamName:"Game company",gameName:"Game name",shortDesc:"Short description",thumbnail:"Thumbnail picture",chooseImg:"Choose picture",gameLink:"Game link",linkPh:"https://your-game.netlify.app",
  optional:"Optional",must:"Must",emailHint:"So your teacher can contact you",thumbHint:"No picture? We'll make one from your initials.",submitGame:"Add my game",
  badLink:"Paste your live Netlify link. It ends in .netlify.app",dupLink:"This game link is already in the gallery.",needTitle:"Enter your game name.",needS1:"Enter your S-number.",added:"Your game is in the gallery!",adminImport:"Admin: import games from the Google Form (CSV)",
  adminOnly:"Admin access only",enterPw:"Enter password",wrongPw:"That code is not right.",unlock:"Unlock",cancel:"Cancel",
  editTitle:"Edit game",editAsk:"Type your S-number to edit your game.",editNotYours:"That S-number isn't on this game.",continue:"Continue",saveChanges:"Save changes",
  studentEditNote:"You can change the picture, game name, game company and description. To change the link or remove the game, ask your teacher.",deleteGame:"Delete game",deleteAsk:"Delete this game? Enter the admin code to confirm.",deleted:"Game deleted",saved:"Saved",
  setTitle:"Admin settings",allowances:"AI Coins for each person",studentsLbl:"Students",visitorsLbl:"Parents and visitors",saveAllow:"Save amounts",replenish:"Give everyone more AI Coins",replAmount:"Coins to add",replTo:"Give to",everyone:"Everyone",give:"Give coins",gave:"Added {n} AI Coins for {w}",
  overview:"Right now",demo:"Prototype tools",demoFill:"Add sample investments",demoReset:"Reset all prototype data",demoFilled:"Sample investments added",resetDone:"Prototype reset",resetSure:"Tap again to confirm reset",
  accountsN:"{s} students and {v} visitors signed up · {c} AI Coins invested",
  csvTitle:"Import games from CSV",csvLead:"Choose the CSV downloaded from the Google Form responses sheet. Games already in the gallery are skipped (same link, or same game name in the same class), so you can import the latest sheet any time.",csvChoose:"Choose CSV file",csvReady:"{n} new games ready to import · {d} already in the gallery · {b} rows without a valid link",csvImport:"Import {n} games",csvDone:"Imported {n} games",csvNoS:"{n} students have no S-number yet. Add them with the edit button.",
  qrTitle:"Scan to play",openGame:"Open game",close:"Close",liked:"Liked",
  showMore:"Show more",showLess:"Show less",fullScreen:"Full screen",exitFull:"Exit full screen",
  backGallery:"Back to gallery",backRank:"Back to rankings",newTab:"New tab",previewNote:"This preview can't show games inside the page. Open the game in a new tab, then come back here. On the live site the game plays right here.",
  whoEdits:"Who is editing?",admin:"Admin",editStudentSub:"Change your game's picture and details",editAdminSub:"Teachers only",
  csvBoxTitle:"Import games from the Google Form",csvBoxLead:"Teachers only. Upload the CSV of form responses to add every submitted game at once.",csvBoxBtn:"Import CSV",
  stats:"Statistics",stVisitors:"Parents and visitors signed up",stStudents:"Student accounts (investors and game makers)",stGames:"Games uploaded",stMakers:"Students who made games",stGiven:"Starting AI Coins given out",stInvested:"AI Coins invested",stLeft:"AI Coins not yet invested",
 },
 ar:{
  dupTitle:"توجد لعبة بهذا الاسم في شعبتك. اختر اسمًا آخر.",badImage:"لا يمكن استخدام هذه الصورة. اختر صورة JPG أو PNG.",locked:"محاولات خاطئة كثيرة. تم إيقاف دخول المشرف لمدة ١٠ دقائق.",network:"تعذر الاتصال بالساحة الآن. تحقق من الإنترنت وحاول مرة أخرى.",badCode:"يجب أن يتكون الرمز الجديد من ٤ إلى ١٢ رقمًا.",noGame:"هذه اللعبة لم تعد في المعرض.",
  notConfigured:"الساحة غير متصلة بقاعدة البيانات بعد. أضف بيانات Supabase في config.js.",loadError:"تعذر تحميل الألعاب الآن.",retry:"حاول مرة أخرى",loading:"جارٍ تحميل الألعاب…",all:"الكل",removePic:"إزالة الصورة",
  bonusNow:"العملات الإضافية حتى الآن: الطلاب +{s}، أولياء الأمور والزوار +{v}",changeCode:"تغيير رمز المشرف",newCode:"الرمز الجديد (٤–١٢ رقمًا)",saveCode:"حفظ الرمز الجديد",codeSaved:"تم تغيير رمز المشرف",
  startFresh:"البدء من جديد",startFreshLead:"يحذف كل التسجيلات والاستثمارات والإعجابات. تبقى الألعاب. استخدمه بعد التجربة.",clearBtn:"مسح كل العملات والإعجابات والتسجيلات",cleared:"تم مسح كل العملات والإعجابات والتسجيلات",
  footer:"البرنامج متعدد التخصصات · ساحة ألعاب AIS",
  tabProfile:"حسابي",seeInvestors:"عرض المستثمرين",investorsOf:"المستثمرون في {g}",noInvestorsYet:"لم يستثمر أحد في هذه اللعبة بعد.",investorsLead:"{n} عملة مستثمرة. الأكثر استثمارًا أولاً.",
  checkTitle:"قبل أن تظهر لعبتك في المعرض",checkLead:"ضع علامة على كل قاعدة لتأكيد أن لعبتك تلتزم بقواعد ساحة ألعاب AIS.",checkGo:"تأكيد ونشر",
  me_rule1:"صورة لعبتي مناسبة وتلتزم بالآداب الإسلامية.",me_rule2:"شخصيات لعبتي مناسبة وتلتزم بالآداب الإسلامية.",me_rule3:"طريقة اللعب مناسبة وتلتزم بالآداب الإسلامية (لا قتل للناس ولا سرقة وغير ذلك).",me_rule4:"اسم لعبتي أصلي وغير منسوخ من لعبة موجودة.",
  rulesTitle:"قواعد ساحة ألعاب AIS",rulesShow:"عرض القواعد",rulesHide:"إخفاء",
  rulesText:"استعدادًا لإعادة إطلاق ساحة ألعاب AIS، يرجى مراجعة لعبتك وتعديلها للتأكد من خلوها من أي محتوى غير لائق (مثل GTA). يجب أن تكون الألعاب مناسبة وتلتزم بالآداب الإسلامية لساحة ألعاب AIS حتى تُقبل في المعرض. تجنّب الصور غير اللائقة وأسماء الألعاب الموجودة مسبقًا. شكرًا لتفهمكم وتعاونكم.",
  rule1:"صور الألعاب مناسبة وتلتزم بالآداب الإسلامية.",rule2:"شخصيات الألعاب مناسبة وتلتزم بالآداب الإسلامية.",rule3:"طريقة اللعب مناسبة وتلتزم بالآداب الإسلامية (لا قتل للناس ولا سرقة وغير ذلك).",rule4:"لكل لعبة اسم أصلي غير منسوخ من لعبة موجودة.",
  minNote:"أقل استثمار هو {m} عملة.",minInvest:"يجب أن تستثمر {m} عملة على الأقل.",visitorsLocked:"يمكن لأولياء الأمور والزوار الاستثمار عند فتحه في اجتماع أولياء الأمور.",visitorsLockedShort:"يُفتح في اجتماع أولياء الأمور",
  myProfile:"حسابي",profileTitle:"حسابي",profileLead:"عملاتك، والألعاب التي استثمرت فيها، وما ربحته لعبتك.",profileSignIn:"سجّل الدخول لترى عملاتك واستثماراتك.",signInBtn:"تسجيل الدخول",
  startCoins:"العملات في البداية",investedNow:"العملات المستثمرة الآن",earnedTotal:"أرباح لعبتي",owed:"سحب أحدهم استثماره من لعبتك بعد أن أنفقت تلك العملات، لذا عليك {n} عملة. الاستثمارات الجديدة في لعبتك تسدد هذا أولاً.",
  portfolio:"استثماراتي",portfolioLead:"غيّرت رأيك؟ اسحب استثمارك لتستعيد عملاتك. رسوم خدمة السحب {f} عملة تبقى في اللعبة.",withdraw:"سحب",keptFee:"الرسوم باقية في اللعبة",
  myGames:"ألعابي",myGamesLead:"عندما يستثمر أحد في لعبتك، تُقسم العملات بالتساوي بين الطلاب الذين صنعوها.",gameHas:"{n} عملة من {i} مستثمرين",
  withdrawTitle:"السحب من {g}",youHaveIn:"لديك {n} عملة في هذه اللعبة",withdrawExplain:"ستستعيد {b} عملة. تبقى {f} عملة في اللعبة كرسوم خدمة السحب.",withdrawGo:"اسحب {b} عملة",withdrawn:"عادت {b} عملة إلى حسابك",
  nothingToWithdraw:"لم يبق في هذه اللعبة إلا رسوم {f} عملة، فلا يوجد ما يُسحب.",rulesNeeded:"ضع علامة على القواعد الأربع لنشر لعبتك.",
  visitorsTitle:"أولياء الأمور والزوار",visitorsOpenNow:"يمكن لأولياء الأمور والزوار التسجيل والاستثمار الآن.",visitorsLockedNow:"مغلق. لا يمكن لأولياء الأمور والزوار التسجيل أو الاستثمار حتى تفتحه.",lockVisitors:"إغلاق أولياء الأمور والزوار",openVisitors:"فتح لأولياء الأمور والزوار",visitorsOpened:"يمكن لأولياء الأمور والزوار الاستثمار الآن",visitorsLockedToast:"تم إغلاق أولياء الأمور والزوار",
  stEarned:"عملات ربحها صانعو الألعاب",stWithdrawals:"عمليات السحب",
  startFresh:"إعادة ضبط العملات",startFreshLead:"يعيد كل حساب إلى عملاته في البداية: يحذف كل الاستثمارات والأرباح والعملات الإضافية. تبقى الألعاب والصور والأوصاف والتسجيلات والإعجابات.",resetCoinsBtn:"إعادة ضبط كل العملات",coinsReset:"عادت كل العملات إلى البداية",clearAllLead:"فقط إذا احتجت بداية جديدة تمامًا: يحذف أيضًا كل التسجيلات والإعجابات. تبقى الألعاب.",clearBtn:"مسح العملات والتسجيلات والإعجابات",
appName:"ساحة ألعاب AIS",brandRest:"ساحة الألعاب",tagline:"مدارس الرواد العالمية · معرض ألعاب الصف الثامن",tabGallery:"معرض الألعاب",tabRankings:"الترتيب",tabInvest:"استثمر",tabUpload:"ارفع لعبتك",
  galleryTitle:"معرض الألعاب",galleryLead:"جرّب اللعبة، واضغط على القلب إذا أعجبتك، ثم استثمر عملاتك في ألعابك المفضلة.",searchPh:"ابحث باسم اللعبة أو اسم الطالب أو الرقم الأكاديمي",allClasses:"كل الشعب",
  classN:"شعبة {c}",games:"{n} لعبة",game1:"لعبة واحدة",play:"العب",invest:"استثمر",coins:"عملة ذكاء",investors:"المستثمرون",likes:"الإعجابات",scan:"امسح للعب",prev:"السابق",next:"التالي",pageOf:"صفحة {p} من {n}",noGames:"لا توجد ألعاب تطابق بحثك.",
  rankTitle:"أفضل ١٠ ألعاب",rankLead:"ترتيب الألعاب حسب عملات الذكاء المستثمرة. أفضل ١٠ ألعاب عليها كأس وستُعرض في المعرض.",celebrate:"احتفل!",rank:"المركز",game:"اللعبة",team:"شركة الألعاب",exhibition:"لعبة المعرض",first:"المركز الأول",second:"المركز الثاني",third:"المركز الثالث",waiting:"بانتظار أول استثمار",investorsN:"{n} مستثمرين",investor1:"مستثمر واحد",
  wallet:"لديك {n} عملة ذكاء",walletShort:"{n}",
  invTitle:"استثمر",invLead:"اختر من أنت. تحصل على عملاتك مرة واحدة، وتبقى في حسابك عندما تعود. ويربح الطلاب عملات عندما يستثمر الآخرون في لعبتهم.",student:"طالب",studentSub:"استخدم رقمك الأكاديمي",studentGet:"{n} عملة ذكاء",visitor:"ولي أمر أو زائر",visitorSub:"استخدم اسمك وبريدك الإلكتروني",
  snum:"الرقم الأكاديمي",snumPh:"مثال: S123456",name:"الاسم",cls:"الشعبة",findMe:"اكتب رقمك الأكاديمي وسيظهر اسمك.",notFound:"لم نجد هذا الرقم الأكاديمي. تأكد منه وحاول مرة أخرى.",notG8:"رفع الألعاب لطلاب الصف الثامن فقط.",found:"تم العثور: {n} · {c}",
  startInvesting:"ابدأ الاستثمار",welcomeBack:"أهلاً بعودتك",newHere:"جديد هنا",haveAccount:"لدي حساب",firstName:"الاسم الأول",surname:"اسم العائلة",email:"البريد الإلكتروني",createAccount:"إنشاء حساب",logIn:"تسجيل الدخول",
  emailTaken:"هذا البريد له حساب بالفعل. اختر «لدي حساب» لتسجيل الدخول.",noEmail:"لا يوجد حساب بهذا البريد. اختر «جديد هنا» لإنشاء حساب.",badEmail:"اكتب بريدًا إلكترونيًا كاملاً مثل name@example.com.",needName:"اكتب اسمك الأول واسم العائلة.",
  youHave:"لديك",coinsLeft:"عملة ذكاء متبقية للاستثمار",myInv:"استثماراتك",noInv:"لم تستثمر بعد. افتح معرض الألعاب واختر لعبة تعجبك.",goGallery:"اذهب إلى معرض الألعاب",signOut:"تسجيل الخروج",
  invModal:"استثمر في {g}",howMany:"كم عملة؟",confirmInv:"استثمر {n} عملة",ownGame:"هذه لعبتك، لذلك لا يمكنك الاستثمار فيها. جرّب لعبة أخرى!",notEnough:"لديك {n} عملة فقط.",invested:"استثمرت {n} عملة في {g}",signInFirst:"اختر طالب أو ولي أمر أولاً، ثم يمكنك الاستثمار.",wholeNumber:"اكتب عددًا صحيحًا من العملات.",
  upTitle:"ارفع لعبتك",upLead:"اكتب بياناتك ورابط Netlify. ستظهر بطاقة لعبتك في المعرض فورًا.",s1:"رقمك الأكاديمي",s2:"الرقم الأكاديمي لزميلك",teamName:"شركة الألعاب",gameName:"اسم اللعبة",shortDesc:"وصف قصير",thumbnail:"صورة اللعبة",chooseImg:"اختر صورة",gameLink:"رابط اللعبة",linkPh:"https://your-game.netlify.app",
  optional:"اختياري",must:"مطلوب",emailHint:"ليتمكن معلمك من التواصل معك",thumbHint:"لا توجد صورة؟ سنصنع واحدة من الأحرف الأولى لأسمائكم.",submitGame:"أضف لعبتي",
  badLink:"الصق رابط Netlify المنشور. ينتهي بـ ‎.netlify.app",dupLink:"رابط هذه اللعبة موجود بالفعل في المعرض.",needTitle:"اكتب اسم لعبتك.",needS1:"اكتب رقمك الأكاديمي.",added:"لعبتك الآن في المعرض!",adminImport:"للمشرف: استيراد الألعاب من نموذج Google ‏(CSV)",
  adminOnly:"للمشرف فقط",enterPw:"أدخل كلمة المرور",wrongPw:"الرمز غير صحيح.",unlock:"فتح",cancel:"إلغاء",
  editTitle:"تعديل اللعبة",editAsk:"اكتب رقمك الأكاديمي لتعديل لعبتك.",editNotYours:"هذا الرقم الأكاديمي ليس في هذه اللعبة.",continue:"متابعة",saveChanges:"حفظ التغييرات",
  studentEditNote:"يمكنك تغيير الصورة واسم اللعبة وشركة الألعاب والوصف. لتغيير الرابط أو حذف اللعبة اطلب من معلمك.",deleteGame:"حذف اللعبة",deleteAsk:"حذف هذه اللعبة؟ أدخل رمز المشرف للتأكيد.",deleted:"تم حذف اللعبة",saved:"تم الحفظ",
  setTitle:"إعدادات المشرف",allowances:"عملات الذكاء لكل شخص",studentsLbl:"الطلاب",visitorsLbl:"أولياء الأمور والزوار",saveAllow:"حفظ",replenish:"امنح الجميع عملات إضافية",replAmount:"عدد العملات",replTo:"لمن",everyone:"الجميع",give:"امنح العملات",gave:"تمت إضافة {n} عملة لـ {w}",
  overview:"الآن",demo:"أدوات النسخة التجريبية",demoFill:"أضف استثمارات تجريبية",demoReset:"إعادة ضبط كل البيانات",demoFilled:"تمت إضافة استثمارات تجريبية",resetDone:"تمت إعادة الضبط",resetSure:"اضغط مرة أخرى للتأكيد",
  accountsN:"{s} طالب و{v} زائر مسجلون · {c} عملة مستثمرة",
  csvTitle:"استيراد الألعاب من CSV",csvLead:"اختر ملف CSV المحمّل من ردود نموذج Google. الألعاب الموجودة لن تتكرر (نفس الرابط أو نفس اسم اللعبة في نفس الشعبة)، لذا يمكنك استيراد أحدث ملف في أي وقت.",csvChoose:"اختر ملف CSV",csvReady:"{n} لعبة جديدة جاهزة · {d} موجودة بالفعل · {b} صفوف بدون رابط صحيح",csvImport:"استورد {n} لعبة",csvDone:"تم استيراد {n} لعبة",csvNoS:"{n} طالب بدون رقم أكاديمي. أضفه من زر التعديل.",
  qrTitle:"امسح للعب",openGame:"افتح اللعبة",close:"إغلاق",liked:"أعجبني",
  showMore:"اقرأ المزيد",showLess:"عرض أقل",fullScreen:"ملء الشاشة",exitFull:"الخروج من ملء الشاشة",
  backGallery:"العودة إلى المعرض",backRank:"العودة إلى الترتيب",newTab:"نافذة جديدة",previewNote:"هذه المعاينة لا تعرض الألعاب داخل الصفحة. افتح اللعبة في نافذة جديدة ثم عد إلى هنا. في الموقع الفعلي تعمل اللعبة هنا مباشرة.",
  whoEdits:"من يقوم بالتعديل؟",admin:"المشرف",editStudentSub:"غيّر صورة لعبتك وتفاصيلها",editAdminSub:"للمعلمين فقط",
  csvBoxTitle:"استيراد الألعاب من نموذج Google",csvBoxLead:"للمعلمين فقط. ارفع ملف CSV لردود النموذج لإضافة كل الألعاب مرة واحدة.",csvBoxBtn:"استيراد CSV",
  stats:"الإحصائيات",stVisitors:"أولياء الأمور والزوار المسجلون",stStudents:"الطلاب المسجلون للاستثمار",stGames:"الألعاب المرفوعة",stMakers:"الطلاب صانعو الألعاب",stGiven:"عملات الذكاء الموزعة",stInvested:"عملات الذكاء المستثمرة",stLeft:"عملات لم تُستثمر بعد",
 }
};
const t = (k, v={}) => (T[lang][k] ?? T.en[k] ?? k).replace(/\{(\w+)\}/g, (_,x)=> v[x] ?? "");

/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const I = {
 coin:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="9" cy="9" r="6"/><path d="M15.5 9.5a6 6 0 1 1-6 6"/><path d="M9 6.5v5M7 9h4"/></svg>',
 users:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M16 4a4 4 0 0 1 0 8M22 21a7 7 0 0 0-4-6.3"/></svg>',
 heart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 21s-8-5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 6-8 11-8 11z"/></svg>',
 play:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15a1 1 0 0 0 1.5.9l12-7.5a1 1 0 0 0 0-1.8l-12-7.5A1 1 0 0 0 7 4.5z"/></svg>',
 pencil:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/></svg>',
 trophy:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 3h10v2h3v3a4 4 0 0 1-4 4h-.3A5 5 0 0 1 13 14.9V18h3v3H8v-3h3v-3.1A5 5 0 0 1 8.3 12H8a4 4 0 0 1-4-4V5h3zm0 4H6v1a2 2 0 0 0 1 1.7zm10 0v2.7A2 2 0 0 0 18 8V7z"/></svg>',
 full:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
 chart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
 ext:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
 x:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
 shield:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 6v6c0 4.5 3.4 8.2 8 9 4.6-.8 8-4.5 8-9V6z"/><path d="m9 12 2 2 4-4"/></svg>',
 lock:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>',
 student:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 9 12 4 2 9l10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/></svg>',
 family:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="8" cy="6" r="3"/><circle cx="17" cy="9" r="2.4"/><path d="M3 21v-3a5 5 0 0 1 10 0v3M14 21v-2.5a3.5 3.5 0 0 1 7 0V21"/></svg>',
 file:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5"/></svg>',
 image:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/></svg>',
};
const GRADS = [["#00c6ff","#0050ff"],["#7f00ff","#e100ff"],["#f857a6","#ff5858"],["#0fb39b","#38ef7d"],["#ff6a00","#ee0979"],["#8e2de2","#4a00e0"],["#00b4db","#3a47d5"],["#ff512f","#dd2476"],["#1fa2ff","#a12bff"],["#f7971e","#ff3d6e"],["#00d2a8","#0072ff"],["#c33764","#5b3cff"]];
function hseed(s){ let h=0; for(const ch of String(s)) h=(h*31+ch.codePointAt(0))>>>0; return h; }
function grad(s){ const [a,b] = GRADS[hseed(s)%GRADS.length]; const ang = 110 + hseed(s+"a")%70; return `radial-gradient(120% 90% at 85% 10%, rgba(255,255,255,.22), transparent 55%), linear-gradient(${ang}deg, ${a}, ${b})`; }
const hue = s => GRADS[hseed(s)%GRADS.length][0];
function letterOf(s){ const m = String(s||"").match(/[A-Za-z0-9؀-ۿ]/); return m ? m[0].toUpperCase() : ""; }
const initialOf = letterOf;
function initialsOf(g){ const L = (g.students||[]).map(s=>letterOf(s.n)).filter(Boolean).slice(0,3).join(""); return L || letterOf(g.title) || "?"; }
const qrCache = new Map();
function qrSvg(url){
  if(qrCache.has(url)) return qrCache.get(url);
  let svg = "";
  try{ if(window.qrcode){ const q = qrcode(0,"M"); q.addData(url); q.make(); svg = q.createSvgTag({cellSize:4, margin:0, scalable:true}); } }catch(e){}
  if(svg) qrCache.set(url, svg);
  return svg;
}
const shortName = n => { const p = String(n).trim().split(/\s+/); return p.length>2 ? p[0]+" "+p[p.length-1] : String(n).trim(); };
const fmt = n => Number(n).toLocaleString("en-US");
function toast(msg){ const el=$("#toast"); el.textContent=msg; el.hidden=false; clearTimeout(toast._t); toast._t=setTimeout(()=>el.hidden=true, 2600); }
const normS = s => String(s||"").trim().toUpperCase().replace(/\s+/g,"");

/* ---------- talking to the database ---------- */
const CFG = window.ARENA_CONFIG || {};
const API = (CFG.API_BASE || (String(CFG.SUPABASE_URL||"").replace(/\/+$/,"") + "/rest/v1")) + "/rpc/";
const CONFIGURED = !!(CFG.API_BASE || (CFG.SUPABASE_URL && !/YOUR-PROJECT/.test(CFG.SUPABASE_URL) && CFG.SUPABASE_ANON_KEY && !/YOUR-ANON-KEY/.test(CFG.SUPABASE_ANON_KEY)));
async function api(fn, args = {}){
  let r;
  try{
    const key = CFG.SUPABASE_ANON_KEY || "", headers = { "Content-Type":"application/json", "apikey": key };
    if(/^eyJ/.test(key)) headers.Authorization = "Bearer " + key;     // older "anon" keys; newer "publishable" keys only need apikey
    r = await fetch(API + fn, { method:"POST", headers, body: JSON.stringify(args) });
  }catch(e){ return {error:"NETWORK"}; }
  let j = null; try{ j = await r.json(); }catch(e){}
  if(!r.ok) return {error:"NETWORK", detail: j && j.message};
  return j;
}
const ERR = {NOT_FOUND:"notFound", S2_NOT_FOUND:"notFound", NOT_G8:"notG8", BAD_LINK:"badLink", DUP_LINK:"dupLink", DUP_TITLE:"dupTitle", NEED_TITLE:"needTitle",
  NEED_S1:"needS1", BAD_IMAGE:"badImage", OWN_GAME:"ownGame", NOT_ENOUGH:"notEnough", BAD_AMOUNT:"wholeNumber", EMAIL_TAKEN:"emailTaken", NO_ACCOUNT:"noEmail",
  BAD_EMAIL:"badEmail", NEED_NAME:"needName", WRONG_CODE:"wrongPw", LOCKED:"locked", NOT_YOURS:"editNotYours", NO_SESSION:"signInFirst", NETWORK:"network",
  BAD_CODE:"badCode", NO_GAME:"noGame", BAD_DEVICE:"network", VISITORS_LOCKED:"visitorsLocked", MIN_INVEST:"minInvest",
  NOTHING_TO_WITHDRAW:"nothingToWithdraw", RULES:"rulesNeeded"};
const errText = (res) => t(ERR[res.error] || "network", {n: res.balance ?? "", m: res.min ?? MIN(), f: res.fee ?? FEE()});
const MIN = () => S.settings.min_invest ?? 20, FEE = () => S.settings.withdraw_fee ?? 20;

/* ---------- local state (a copy of what the database says) ---------- */
let S = { games:[], settings:{student:300, visitor:100, visitors_open:false, min_invest:20, withdraw_fee:20} };
let ME = null;                                   // signed-in account on this device
let token = store.get(KEY+"-token");
let device = store.get(KEY+"-device"); if(!device){ device = "d"+Math.random().toString(36).slice(2,12)+Date.now().toString(36); store.set(KEY+"-device", device); }
lang = store.get(KEY+"-lang") || "en";
let loaded = false, loadError = false;
const thumbs = new Map();                        // id -> {v, data}

async function loadState(){
  const res = await api("get_state", {p_device: device});
  if(res.error || !res.games){ loadError = true; return false; }
  loadError = false; loaded = true;
  S = res; S.games.forEach(g => { g.students = g.students || []; });
  const need = S.games.filter(g => g.thumb_v && thumbs.get(g.id)?.v !== g.thumb_v).map(g => g.id);
  for(let i=0;i<need.length;i+=30){
    const ids = need.slice(i, i+30), got = await api("get_thumbs", {p_ids: ids});
    if(got && !got.error) ids.forEach(id => { const g = S.games.find(x=>x.id===id); if(got[id] && g) thumbs.set(id, {v:g.thumb_v, data:got[id]}); });
  }
  return true;
}
async function loadMe(){
  if(!token){ ME = null; return; }
  const res = await api("get_me", {p_token: token});
  if(res.error){ if(res.error==="NO_SESSION"){ token = null; store.set(KEY+"-token", null); } ME = null; return; }
  ME = res;
}
function setMe(res){ ME = res; token = res.token; store.set(KEY+"-token", token); }

/* ---------- thumbnails ---------- */
function art(g){
  const th = g.thumbData || thumbs.get(g.id)?.data;
  if(th) return `<img src="${esc(th)}" alt="" loading="lazy">`;
  const L = initialsOf(g);
  return `<div class="initial n${L.length}" style="background:${grad(g.id+g.title)}">${esc(L)}</div>`;
}

/* ---------- derived numbers ---------- */
function ranked(){
  const list = S.games.map(g => ({g, coins:g.coins, inv:g.investors, likes:g.likes}));
  list.sort((a,b)=> b.coins-a.coins || b.inv-a.inv || b.likes-a.likes || a.g.title.localeCompare(b.g.title));
  let rank = 0, prev = null;
  list.forEach((r,i)=>{ const k = r.coins+"|"+r.inv; if(k!==prev){ rank = i+1; prev = k; } r.rank = r.coins>0 ? rank : null; });
  return list;
}

/* ---------- routing ---------- */
const MAIN = ["gallery","rankings","invest","upload","profile"], TABS = [...MAIN, "play"];
let tab = MAIN.includes(location.hash.slice(1)) ? location.hash.slice(1) : "gallery";
function show(name){
  if(tab==="play" && name!=="play"){ exitFull(); $("#p-play").innerHTML = ""; }      // stop the game when leaving
  tab = name;
  document.querySelectorAll("nav.tabs button").forEach(b=> b.getAttribute("data-go")===name ? b.setAttribute("aria-current","page") : b.removeAttribute("aria-current"));
  TABS.forEach(n => $("#p-"+n).hidden = n!==name);
  render();
}
function go(name){
  show(name);
  try{ history.replaceState(null, "", "#"+name); }catch(e){}
  window.scrollTo({top:0});
}
/* Play opens inside the arena. Back (our button or the browser's) returns to the same page and scroll position. */
let playing = null, playFrom = "gallery", playScroll = 0;
function openPlay(gid){
  closeModal();
  if(tab!=="play"){ playFrom = tab; playScroll = window.scrollY; }
  playing = gid; show("play");
  try{ history.pushState({arena:"play"}, "", "#play"); }catch(e){}
  window.scrollTo({top:0});
}
function leavePlay(){
  show(playFrom);
  try{ history.replaceState(null, "", "#"+playFrom); }catch(e){}
  requestAnimationFrame(() => window.scrollTo({top:playScroll}));
}
addEventListener("popstate", () => { if(tab==="play") leavePlay(); });
document.addEventListener("click", e => { const g = e.target.closest("[data-go]"); if(g){ e.preventDefault(); go(g.getAttribute("data-go")); } });

/* ---------- filters ---------- */
const view = { gallery:{q:"",cls:"",page:1,ids:null}, rankings:{q:"",cls:"",page:1,ids:null} };
const PER = 10, GPER = 12;
function matches(g, v){
  if(v.cls && g.cls!==v.cls) return false;
  const q = v.q.trim(); if(!q) return true;
  if(/^s\d{6}$/i.test(q)) return !!(v.ids && v.ids.includes(g.id));
  const hay = [g.title, g.team, g.cls, ...g.students.map(s=>s.n)].join(" ").toLowerCase();
  return q.toLowerCase().split(/\s+/).filter(Boolean).every(w => hay.includes(w));
}
function classOptions(sel, cur){
  const set = [...new Set(S.games.map(g=>g.cls))].sort();
  sel.innerHTML = `<option value="">${esc(t("allClasses"))}</option>` + set.map(c=>`<option value="${esc(c)}"${c===cur?" selected":""}>${esc(t("classN",{c}))}</option>`).join("");
}
function pager(el, page, pages, onGo){
  if(pages<=1){ el.innerHTML=""; return; }
  el.innerHTML = `<button class="btn ghost" ${page<=1?"disabled":""} data-p="${page-1}">${lang==="ar"?"→":"←"} ${esc(t("prev"))}</button>
    <span class="num">${esc(t("pageOf",{p:page,n:pages}))}</span>
    <button class="btn ghost" ${page>=pages?"disabled":""} data-p="${page+1}">${esc(t("next"))} ${lang==="ar"?"←":"→"}</button>`;
  el.querySelectorAll("[data-p]").forEach(b=> b.onclick = () => { onGo(+b.dataset.p); window.scrollTo({top:0, behavior:"smooth"}); });
}
for(const [name, qi, ci] of [["gallery","#gq","#gcls"],["rankings","#rq","#rcls"]]){
  $(qi).addEventListener("input", async e => {
    const v = view[name]; v.q = e.target.value; v.page = 1; v.ids = null;
    if(/^s\d{6}$/i.test(v.q.trim())){ const q = v.q; const res = await api("find_games", {p_s: q.trim()}); if(v.q!==q) return; v.ids = Array.isArray(res) ? res : []; }
    softRender();
  });
  $(ci).addEventListener("change", e => { view[name].cls = e.target.value; view[name].page = 1; softRender(); });
}
function statusBlock(){
  if(!CONFIGURED) return `<div class="empty">${esc(t("notConfigured"))}</div>`;
  if(loadError) return `<div class="empty">${esc(t("loadError"))} <button class="btn ghost" id="retry" style="margin-top:12px">${esc(t("retry"))}</button></div>`;
  return `<div class="empty">${esc(t("loading"))}</div>`;
}
document.addEventListener("click", e => { if(e.target.closest("#retry")) refresh(); });

/* ---------- gallery ---------- */
function renderGallery(){
  const v = view.gallery;
  renderRules();
  classOptions($("#gcls"), v.cls);
  if($("#gq").value!==v.q) $("#gq").value = v.q;
  if(!loaded){ $("#ggrid").innerHTML = statusBlock(); $("#gcount").textContent = ""; $("#gpager").innerHTML = ""; return; }
  const rk = Object.fromEntries(ranked().map(r=>[r.g.id, r.rank]));
  const list = S.games.filter(g=>matches(g, v));
  $("#gcount").textContent = list.length===1 ? t("game1") : t("games",{n:list.length});
  const pages = Math.max(1, Math.ceil(list.length/GPER)); v.page = Math.min(v.page, pages);
  const slice = list.slice((v.page-1)*GPER, v.page*GPER);
  const open = new Set([...document.querySelectorAll(".desc.open")].map(d=>d.id));
  $("#ggrid").innerHTML = slice.length ? slice.map(g=>{
    const top = rk[g.id] && rk[g.id]<=10;
    const names = g.students.map(x=>esc(shortName(x.n))).join(" &amp; ");
    return `<article class="card">
      <div class="thumb">${art(g)}
        <span class="chip cls">${esc(g.cls)}</span>
        ${top?`<span class="chip trophy">${I.trophy} #${rk[g.id]}</span>`:""}
        <button class="edit" data-edit="${g.id}" aria-label="${esc(t("editTitle"))}">${I.pencil}</button>
      </div>
      <div class="cbody">
        <div><h3>${esc(g.title)}</h3><div class="who">${g.team?`<b>${esc(g.team)}</b> · `:""}${names}</div></div>
        ${g.desc?`<div class="descwrap"><p class="desc" id="d-${g.id}">${esc(g.desc)}</p><button class="more" data-more="${g.id}" aria-controls="d-${g.id}" aria-expanded="false" hidden>${esc(t("showMore"))}</button></div>`:""}
        <div class="qrrow">
          <button class="qr" data-qr="${g.id}" aria-label="${esc(t("scan"))}">${qrSvg(g.url)}</button>
          <div class="stats">
            <div class="stat coins"><span>${I.coin}${esc(t("coins"))}</span><strong>${fmt(g.coins)}</strong></div>
            <button class="stat" data-investors="${g.id}" title="${esc(t("seeInvestors"))}"><span>${I.users}${esc(t("investors"))}</span><strong>${g.investors}</strong></button>
          </div>
        </div>
        <div class="actions">
          <a class="btn play" href="#play" data-play="${g.id}">${I.play}${esc(t("play"))}</a>
          <button class="btn invest" data-invest="${g.id}">${I.coin}${esc(t("invest"))}</button>
          <button class="like" data-like="${g.id}" aria-pressed="${!!g.liked}" aria-label="${esc(t("liked"))}">${I.heart}<span class="num">${g.likes}</span></button>
        </div>
      </div>
    </article>`;}).join("") : `<div class="empty">${esc(t("noGames"))}</div>`;
  pager($("#gpager"), v.page, pages, p=>{ v.page=p; softRender(); });
  $("#ggrid").querySelectorAll(".desc").forEach(d => {
    if(open.has(d.id)){ d.classList.add("clamped","open"); const b = d.nextElementSibling; b.hidden = false; b.textContent = t("showLess"); b.setAttribute("aria-expanded","true"); return; }
    if(d.scrollHeight > d.clientHeight + 2){ d.classList.add("clamped"); d.nextElementSibling.hidden = false; }
  });
}
document.addEventListener("click", e => {
  const lk = e.target.closest("[data-like]"); if(lk){ toggleLike(lk.dataset.like); return; }
  const iv = e.target.closest("[data-invest]"); if(iv){ openInvest(iv.dataset.invest); return; }
  const mo = e.target.closest("[data-more]") || (e.target.closest(".desc.clamped") && e.target.closest(".descwrap").querySelector("[data-more]"));
  if(mo){ const d = document.getElementById("d-"+mo.dataset.more), open = !d.classList.contains("open");
    d.classList.toggle("open", open); mo.setAttribute("aria-expanded", open); mo.textContent = t(open?"showLess":"showMore"); return; }
  const ed = e.target.closest("[data-edit]"); if(ed){ openEdit(ed.dataset.edit); return; }
  const qr = e.target.closest("[data-qr]"); if(qr){ openQR(qr.dataset.qr); return; }
  const pl = e.target.closest("[data-play]"); if(pl){ e.preventDefault(); openPlay(pl.dataset.play); return; }
  const ivs = e.target.closest("[data-investors]"); if(ivs){ openInvestors(ivs.dataset.investors); return; }
});
async function toggleLike(gid){
  const g = S.games.find(x=>x.id===gid); if(!g) return;
  g.liked = !g.liked; g.likes += g.liked ? 1 : -1; paintLike(g, true);       // show it straight away
  const res = await api("toggle_like", {p_device: device, p_game: gid});
  if(res.error){ g.liked = !g.liked; g.likes += g.liked ? 1 : -1; paintLike(g); toast(errText(res)); return; }
  g.liked = res.liked; g.likes = res.likes; paintLike(g);
}
function paintLike(g, pop){
  document.querySelectorAll(`[data-like="${g.id}"]`).forEach(b => { b.setAttribute("aria-pressed", g.liked); b.querySelector(".num").textContent = g.likes; if(pop && g.liked){ b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop"); } });
}

/* ---------- play view: game inside the site with a way back ---------- */
function renderPlay(){
  const el = $("#p-play"), g = S.games.find(x=>x.id===playing);
  if(!g){ go("gallery"); return; }
  el.innerHTML = `<div class="playbar">
      <button class="btn back" id="playBack">${lang==="ar"?"→":"←"} ${esc(t(playFrom==="rankings"?"backRank":"backGallery"))}</button>
      <div class="ptitle"><b>${esc(g.title)}</b><span>${esc(g.cls)}${g.team?" · "+esc(g.team):""} · ${g.students.map(x=>esc(shortName(x.n))).join(" &amp; ")}</span></div>
      <div class="pacts">
        <button class="like" data-like="${g.id}" aria-pressed="${!!g.liked}" aria-label="${esc(t("liked"))}">${I.heart}<span class="num">${g.likes}</span></button>
        <button class="btn invest" data-invest="${g.id}">${I.coin}${esc(t("invest"))}</button>
        <button class="btn ghost" id="fsBtn">${I.full}<span class="nt">${esc(t("fullScreen"))}</span></button>
        <a class="btn ghost" href="${esc(g.url)}" target="_blank" rel="noopener" title="${esc(t("newTab"))}">${I.ext}<span class="nt">${esc(t("newTab"))}</span></a>
      </div>
    </div>
    <div class="stage" id="stage"><button class="fsexit" id="fsExit">${I.x}${esc(t("exitFull"))}</button><iframe src="${esc(g.url)}" title="${esc(g.title)}" allow="fullscreen; autoplay; gamepad; accelerometer; gyroscope" allowfullscreen></iframe></div>`;
}
function goFull(){
  const st = $("#stage"); if(!st) return;
  const req = st.requestFullscreen || st.webkitRequestFullscreen;
  if(req){ try{ const p = req.call(st); p && p.catch && p.catch(()=>st.classList.add("fake-full")); }catch(e){ st.classList.add("fake-full"); } }
  else st.classList.add("fake-full");
}
function exitFull(){
  const st = $("#stage"); st && st.classList.remove("fake-full");
  if(document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(()=>{});
  else if(document.webkitFullscreenElement && document.webkitExitFullscreen) document.webkitExitFullscreen();
}
document.addEventListener("click", e => { if(e.target.closest("#fsBtn")) goFull(); if(e.target.closest("#fsExit")) exitFull(); if(e.target.closest("#playBack")) leavePlay(); });

/* ---------- rankings ---------- */
function renderRankings(){
  const v = view.rankings;
  classOptions($("#rcls"), v.cls);
  if($("#rq").value!==v.q) $("#rq").value = v.q;
  if(!loaded){ $("#podium").innerHTML = ""; $("#rtable").innerHTML = statusBlock(); $("#rcount").textContent = ""; $("#rpager").innerHTML = ""; return; }
  const all = ranked();
  const top3 = all.slice(0,3);
  const podClass = ["p1","p2","p3"], podLabel = ["first","second","third"];
  $("#podium").innerHTML = [1,0,2].map(i=>{
    const r = top3[i]; if(!r) return "<div></div>";
    const has = r.coins>0;
    return `<div class="pod ${podClass[i]}">
      <div class="medal">${i+1}</div>
      <div class="label">${esc(t(podLabel[i]))}</div>
      ${has?`<div class="pthumb">${art(r.g)}</div><h3>${esc(r.g.title)}</h3>
        <p class="who">${esc(r.g.cls)} · ${r.g.students.map(x=>esc(shortName(x.n))).join(" &amp; ")}</p>
        <div class="big num">${fmt(r.coins)} <span style="font-size:.5em">${esc(t("coins"))}</span></div>
        <div class="sub"><button class="linknum" data-investors="${r.g.id}">${esc(r.inv===1?t("investor1"):t("investorsN",{n:r.inv}))}</button></div>
        <a class="btn ${i===0?"invest":"play"}" href="#play" data-play="${r.g.id}">${I.play}${esc(t("play"))}</a>`
      : `<p class="sub">${esc(t("waiting"))}</p>`}
    </div>`;}).join("");
  const list = all.filter(r=>matches(r.g, v));
  $("#rcount").textContent = list.length===1 ? t("game1") : t("games",{n:list.length});
  const pages = Math.max(1, Math.ceil(list.length/PER)); v.page = Math.min(v.page, pages);
  const slice = list.slice((v.page-1)*PER, v.page*PER);
  const mine = new Set(ME?.my_games || []);
  $("#rtable").innerHTML = `<div class="rrow head"><div>${esc(t("rank"))}</div><div>${esc(t("game"))}</div><div>${esc(t("team"))}</div><div>${esc(t("coins"))}</div><div>${esc(t("investors"))}</div><div>${esc(t("likes"))}</div><div></div></div>` +
   (slice.length ? slice.map(r=>{
    const top = r.rank && r.rank<=10;
    return `<div class="rrow${mine.has(r.g.id)?" mine":""}">
      <div class="rank ${r.rank&&r.rank<=3?"r"+r.rank:""}">${top?I.trophy:""}<span class="num">${r.rank?r.rank:"–"}</span></div>
      <div class="rgame"><div class="mini">${art(r.g)}</div><div style="min-width:0"><b>${esc(r.g.title)}</b><small>${esc(r.g.cls)}</small></div></div>
      <div class="rteam">${r.g.team?`<b>${esc(r.g.team)}</b>`:""}${r.g.students.map(x=>esc(shortName(x.n))).join(" &amp; ")}</div>
      <div class="rcoins">${I.coin}<span>${fmt(r.coins)}</span></div>
      <div class="rnum rinv"><button class="linknum" data-investors="${r.g.id}" title="${esc(t("seeInvestors"))}">${r.inv}</button></div>
      <div class="rnum rlikes">${r.likes}</div>
      <div class="rplay"><a class="btn play" href="#play" data-play="${r.g.id}">${I.play}${esc(t("play"))}</a></div>
      <div class="rmeta"><button class="linknum" data-investors="${r.g.id}">${esc(r.inv===1?t("investor1"):t("investorsN",{n:r.inv}))}</button><span>♥ ${r.likes}</span></div>
    </div>`;}).join("") : `<div class="empty" style="border:0">${esc(t("noGames"))}</div>`);
  pager($("#rpager"), v.page, pages, p=>{ v.page=p; softRender(); });
}
function celebrate(){
  if(!window.confetti) return;
  const colors = ["#3fd0ff","#ffb627","#ff5c8a","#3ddc97","#b79bff","#ffffff"];
  const end = Date.now()+3500;
  confetti({particleCount:140, spread:75, startVelocity:58, angle:60, origin:{x:0,y:1}, colors});
  confetti({particleCount:140, spread:75, startVelocity:58, angle:120, origin:{x:1,y:1}, colors});
  setTimeout(()=>confetti({particleCount:120, spread:360, startVelocity:35, origin:{x:.5,y:.35}, shapes:["star"], colors:["#ffcf3f","#ffffff","#ffb627"], scalar:1.3}), 450);
  (function frame(){
    confetti({particleCount:4, angle:270, spread:90, startVelocity:6, gravity:.7, ticks:280, origin:{x:Math.random(), y:-0.05}, colors, scalar:.9});
    if(Date.now()<end) requestAnimationFrame(frame);
  })();
  setTimeout(()=>{ confetti({particleCount:100, spread:80, angle:60, origin:{x:0,y:.9}, colors}); confetti({particleCount:100, spread:80, angle:120, origin:{x:1,y:.9}, colors}); }, 1400);
}
$("#celebrate").addEventListener("click", celebrate);

/* ---------- modal plumbing ---------- */
function modal(title, body, {wide=false}={}){
  const root = $("#modalRoot");
  root.innerHTML = `<div class="overlay" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal${wide?" wide":""}">
    <div class="mhead"><h2>${esc(title)}</h2><button class="x" data-close aria-label="${esc(t("close"))}">${I.x}</button></div>
    <div class="mbody">${body}</div></div></div>`;
  const ov = root.firstElementChild;
  ov.addEventListener("click", e => { if(e.target===ov || e.target.closest("[data-close]")) closeModal(); });
  setTimeout(()=> ov.querySelector("input:not([type=file]),button.btn")?.focus(), 30);
  return ov;
}
function closeModal(){ $("#modalRoot").innerHTML = ""; }
document.addEventListener("keydown", e => { if(e.key==="Escape") closeModal(); });
function busy(btn, on){ if(!btn) return; btn.disabled = on; btn.classList.toggle("busy", on); }

/* Admin code prompt (dots only). The database checks the code; ok(code) runs when it is right. */
function askAdmin(ok, message){
  const ov = modal(t("adminOnly"), `<div class="lock"><div class="ic">${I.lock}</div><b>${esc(message||t("adminOnly"))}</b><span class="hint">${esc(t("enterPw"))}</span></div>
    <form id="pinf" class="field"><input id="pin" class="pin" type="password" inputmode="numeric" maxlength="12" autocomplete="off" aria-label="${esc(t("enterPw"))}"><span class="hint err" id="pinerr"></span>
    <div class="formfoot"><button type="button" class="btn ghost" data-close>${esc(t("cancel"))}</button><button class="btn primary">${esc(t("unlock"))}</button></div></form>`);
  ov.querySelector("#pinf").addEventListener("submit", async e=>{
    e.preventDefault();
    const code = ov.querySelector("#pin").value.trim(), btn = ov.querySelector("#pinf .btn.primary");
    busy(btn, true); const res = await api("admin_check", {p_code: code}); busy(btn, false);
    if(res.ok){ closeModal(); ok(code); }
    else { ov.querySelector("#pinerr").textContent = errText(res); ov.querySelector("#pin").select(); }
  });
}

/* ---------- who invested in a game (most coins first) ---------- */
async function openInvestors(gid){
  const g = S.games.find(x=>x.id===gid); if(!g) return;
  const ov = modal(t("investorsOf",{g:g.title}), `<div id="invlist"><p class="hint" style="margin:0">${esc(t("loading"))}</p></div>`);
  const res = await api("get_investors", {p_game: gid});
  const box = ov.querySelector("#invlist"); if(!box || !box.isConnected) return;
  if(!Array.isArray(res)){ box.innerHTML = `<p class="hint err">${esc(errText(res))}</p>`; return; }
  if(!res.length){ box.innerHTML = `<p class="hint" style="margin:0">${esc(t("noInvestorsYet"))}</p>`; return; }
  box.innerHTML = `<p class="hint" style="margin:0 0 10px">${esc(t("investorsLead",{n:fmt(res.reduce((a,x)=>a+x.coins,0))}))}</p><ol class="invlist">${res.map((x,i)=>`<li>
      <span class="pos num">${i+1}</span>
      <div style="min-width:0"><b>${esc(x.kind==="student"?shortName(x.name):x.name)}</b><small>${esc(x.kind==="student" ? t("student")+(x.cls?" · "+x.cls:"") : t("visitor"))}</small></div>
      <strong>${fmt(x.coins)} ${esc(t("coins"))}</strong></li>`).join("")}</ol>`;
}

/* ---------- rules checklist before a game goes into the gallery ---------- */
function rulesCheck(onOk){
  const items = ["rule1","rule2","rule3","rule4"];
  const ov = modal(t("checkTitle"), `<p class="hint" style="margin:0">${esc(t("checkLead"))}</p>
    <ul class="checks">${items.map((k,i)=>`<li><label><input type="checkbox" id="rc${i}"><span>${esc(t("me_"+k))}</span></label></li>`).join("")}</ul>
    <div class="formfoot"><button type="button" class="btn ghost" data-close>${esc(t("cancel"))}</button><button class="btn primary" id="rcgo" disabled>${esc(t("checkGo"))}</button></div>`);
  const boxes = [...ov.querySelectorAll(".checks input")], go2 = ov.querySelector("#rcgo");
  boxes.forEach(b => b.addEventListener("change", () => { go2.disabled = !boxes.every(x=>x.checked); }));
  go2.onclick = () => { closeModal(); onOk(); };
}

/* ---------- rules banner on the gallery ---------- */
function renderRules(){
  const el = $("#rules"); if(!el) return;
  let closed = !!store.get(KEY+"-rules-closed");
  el.classList.toggle("closed", closed);
  el.innerHTML = `<div class="rhead"><h2 id="rulesTitle">${I.shield}${esc(t("rulesTitle"))}</h2><button class="toggle" id="rulesToggle" aria-expanded="${!closed}">${esc(t(closed?"rulesShow":"rulesHide"))}</button></div>
    <p>${esc(t("rulesText"))}</p>
    <ol>${["rule1","rule2","rule3","rule4"].map(k=>`<li>${esc(t(k))}</li>`).join("")}</ol>`;
  el.querySelector("#rulesToggle").onclick = () => { store.set(KEY+"-rules-closed", !closed); renderRules(); };
}

/* ---------- QR enlarge ---------- */
function openQR(gid){
  const g = S.games.find(x=>x.id===gid); if(!g) return;
  modal(g.title, `<div class="bigqr">${qrSvg(g.url)}</div><p class="hint" style="text-align:center;margin:0;overflow-wrap:anywhere">${esc(g.url)}</p>
    <a class="btn primary" href="#play" data-play="${g.id}">${I.play}${esc(t("openGame"))}</a>`);
}

/* ---------- investing ---------- */
function openInvest(gid){
  const g = S.games.find(x=>x.id===gid); if(!g) return;
  if(!ME){ toast(t("signInFirst")); go("invest"); return; }
  if(ME.kind==="visitor" && !S.settings.visitors_open){ toast(t("visitorsLocked")); return; }
  if((ME.my_games||[]).includes(g.id)){ toast(t("ownGame")); return; }
  const bal = ME.balance, min = MIN();
  const ov = modal(t("invModal",{g:g.title}), `
    <div class="account"><div class="me"><div class="mini" style="width:96px;height:54px">${art(g)}</div><div><b>${esc(g.title)}</b><span>${esc(g.cls)} · ${g.students.map(x=>esc(shortName(x.n))).join(" &amp; ")}</span></div></div></div>
    <div class="note">${esc(t("wallet",{n:fmt(bal)}))}</div>
    <form id="invf" class="field" novalidate><label for="amt">${esc(t("howMany"))}</label>
      <input id="amt" type="number" inputmode="numeric" min="${min}" step="1" value="${bal>=min?min:0}">
      <div class="amounts">${[min,50,100].filter((n,i,a)=>n<=bal && a.indexOf(n)===i).map(n=>`<button type="button" data-amt="${n}">${n}</button>`).join("")}${bal>=min?`<button type="button" data-amt="${bal}">${esc(t("all"))} (${bal})</button>`:""}</div>
      <span class="hint" id="amtmin">${esc(t(bal>=min?"minNote":"minInvest",{m:min}))}</span>
      <span class="hint err" id="amterr"></span>
      <div class="formfoot"><button type="button" class="btn ghost" data-close>${esc(t("cancel"))}</button><button class="btn invest" id="invgo" ${bal<min?"disabled":""}>${I.coin}<span></span></button></div>
    </form>`);
  const amt = ov.querySelector("#amt"), lbl = ov.querySelector("#invgo span");
  const sync = () => { lbl.textContent = t("confirmInv",{n: fmt(+amt.value||0)}); };
  sync(); amt.addEventListener("input", sync);
  ov.querySelectorAll("[data-amt]").forEach(b=> b.onclick = () => { amt.value = b.dataset.amt; sync(); });
  ov.querySelector("#invf").addEventListener("submit", async e=>{
    e.preventDefault();
    const n = Number(amt.value), err = ov.querySelector("#amterr"), btn = ov.querySelector("#invgo");
    if(!Number.isInteger(n) || n<1){ err.textContent = t("wholeNumber"); return; }
    if(n<min){ err.textContent = t("minInvest",{m:min}); return; }
    if(n>ME.balance){ err.textContent = t("notEnough",{n:ME.balance}); return; }
    busy(btn, true);
    const res = await api("invest", {p_token: token, p_game: g.id, p_coins: n});
    busy(btn, false);
    if(res.error){ err.textContent = errText(res); if(res.error==="NO_SESSION"){ ME = null; renderWallet(); } return; }
    setMe(res); g.coins += n;
    closeModal(); softRender(); toast(t("invested",{n:fmt(n), g:g.title}));
    window.confetti && confetti({particleCount:60, spread:60, origin:{y:.7}, colors:["#ffb627","#ffcf3f","#ffffff"]});
    refresh();
  });
}

/* ---------- invest tab (sign in) ---------- */
let who = "student", vmode = "new";
function renderInvest(){
  const el = $("#p-invest");
  if(ME){
    el.innerHTML = `<div class="pagehead"><div><h1>${esc(t("welcomeBack"))}</h1></div></div>
      <div class="box">${accountCard()}
      <div class="formfoot"><button class="btn ghost" data-signout>${esc(t("signOut"))}</button><span style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn ghost" data-go="profile">${esc(t("myProfile"))}</button><button class="btn primary" data-go="gallery">${esc(t("goGallery"))}</button></span></div>
      </div>`;
    return;
  }
  const st = S.settings, vOpen = !!st.visitors_open;
  if(!vOpen && who==="visitor") who = "student";
  el.innerHTML = `<div class="pagehead"><div><h1>${esc(t("invTitle"))}</h1><p>${esc(t("invLead"))}</p></div></div>
    <div class="choice">
      <button data-who="student" aria-pressed="${who==="student"}"><span class="ic">${I.student}</span><b>${esc(t("student"))}</b><span>${esc(t("studentSub"))}</span><em class="num">${esc(t("studentGet",{n:fmt(st.student)}))}</em></button>
      <button data-who="visitor" aria-pressed="${who==="visitor"}" ${vOpen?"":"disabled"}><span class="ic">${vOpen?I.family:I.lock}</span><b>${esc(t("visitor"))}</b><span>${esc(t("visitorSub"))}</span>${vOpen?`<em class="num">${esc(t("studentGet",{n:fmt(st.visitor)}))}</em>`:`<span class="lockbadge">${I.lock}${esc(t("visitorsLockedShort"))}</span>`}</button>
    </div>
    <div class="box" id="signbox"></div>`;
  el.querySelectorAll("[data-who]").forEach(b=> b.onclick = () => { if(b.disabled) return; who = b.dataset.who; renderInvest(); });
  const box = el.querySelector("#signbox");
  if(who==="student"){
    box.innerHTML = `<h2>${esc(t("student"))}</h2><p>${esc(t("findMe"))}</p>
      <form id="sf"><div class="fields">
        <div class="field"><label for="ss">${esc(t("snum"))}<span class="req">${esc(t("must"))}</span></label><input id="ss" autocomplete="off" autocapitalize="characters" placeholder="${esc(t("snumPh"))}"></div>
        <div class="field"><label for="scls">${esc(t("cls"))}</label><input id="scls" readonly tabindex="-1"></div>
        <div class="field full"><label for="sname">${esc(t("name"))}</label><input id="sname" readonly tabindex="-1"></div>
      </div><span class="hint" id="smsg"></span>
      <div class="formfoot"><span></span><button class="btn primary" id="sgo" disabled>${esc(t("startInvesting"))}</button></div></form>`;
    let found = null;
    const ss = box.querySelector("#ss"), msg = box.querySelector("#smsg");
    ss.addEventListener("input", async () => {
      const v = ss.value; found = null; box.querySelector("#sgo").disabled = true;
      box.querySelector("#sname").value = ""; box.querySelector("#scls").value = ""; msg.textContent = ""; msg.className = "hint";
      if(!/^S\d{6}$/.test(normS(v))) return;
      const r = await api("lookup_student", {p_s: v}); if(v!==ss.value) return;
      if(r.error){ msg.textContent = errText(r); msg.className = "hint err"; return; }
      found = r; box.querySelector("#sname").value = r.name; box.querySelector("#scls").value = r.cls; box.querySelector("#sgo").disabled = false;
    });
    box.querySelector("#sf").addEventListener("submit", async e=>{
      e.preventDefault(); if(!found) return;
      const btn = box.querySelector("#sgo"); busy(btn, true);
      const res = await api("student_login", {p_s: found.s}); busy(btn, false);
      if(res.error){ msg.textContent = errText(res); msg.className = "hint err"; return; }
      setMe(res); toast(t("wallet",{n:fmt(ME.balance)})); go("gallery");
    });
  } else {
    box.innerHTML = `<div class="segs"><button data-vm="new" aria-pressed="${vmode==="new"}">${esc(t("newHere"))}</button><button data-vm="login" aria-pressed="${vmode==="login"}">${esc(t("haveAccount"))}</button></div>
      <form id="vf"><div class="fields">
        ${vmode==="new"?`<div class="field"><label for="vfirst">${esc(t("firstName"))}</label><input id="vfirst" autocomplete="given-name"></div>
        <div class="field"><label for="vlast">${esc(t("surname"))}</label><input id="vlast" autocomplete="family-name"></div>`:""}
        <div class="field full"><label for="vemail">${esc(t("email"))}</label><input id="vemail" type="email" autocomplete="email" inputmode="email"></div>
      </div><span class="hint err" id="vmsg"></span>
      <div class="formfoot"><span></span><button class="btn primary">${esc(vmode==="new"?t("createAccount"):t("logIn"))}</button></div></form>`;
    box.querySelectorAll("[data-vm]").forEach(b=> b.onclick = () => { vmode = b.dataset.vm; renderInvest(); });
    box.querySelector("#vf").addEventListener("submit", async e=>{
      e.preventDefault();
      const msg = box.querySelector("#vmsg"), email = box.querySelector("#vemail").value.trim().toLowerCase(), btn = box.querySelector("#vf .btn.primary");
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)){ msg.textContent = t("badEmail"); return; }
      let res;
      busy(btn, true);
      if(vmode==="new"){
        const first = box.querySelector("#vfirst").value.trim(), last = box.querySelector("#vlast").value.trim();
        if(!first || !last){ busy(btn, false); msg.textContent = t("needName"); return; }
        res = await api("visitor_create", {p_first:first, p_last:last, p_email:email});
      } else res = await api("visitor_login", {p_email:email});
      busy(btn, false);
      if(res.error){ msg.textContent = errText(res); return; }
      setMe(res); toast(t("wallet",{n:fmt(ME.balance)})); go("gallery");
    });
  }
}

document.addEventListener("click", e => { if(e.target.closest("[data-signout]")){ ME = null; token = null; store.set(KEY+"-token", null); render(); } });
function accountCard(){
  const nm = ME.name;
  return `<div class="account">
    <div class="me"><div class="avatar" style="background:${grad(nm)}">${esc(initialOf(nm))}</div><div><b>${esc(ME.kind==="student"?shortName(nm):nm)}</b><span>${esc(ME.kind==="student"? t("student")+" · "+ME.cls : ME.email)}</span></div></div>
    <div class="balance num">${fmt(ME.balance)}<small>${esc(t("coinsLeft"))}</small></div>
  </div>`;
}

/* ---------- profile: balance, portfolio, withdrawals ---------- */
function renderProfile(){
  const el = $("#p-profile");
  if(!ME){
    el.innerHTML = `<div class="pagehead"><div><h1>${esc(t("profileTitle"))}</h1><p>${esc(t("profileLead"))}</p></div></div>
      <div class="box"><p style="margin:0 0 14px">${esc(t("profileSignIn"))}</p><button class="btn primary" data-go="invest">${esc(t("signInBtn"))}</button></div>`;
    return;
  }
  const fee = FEE(), inv = ME.invested || {}, earned = ME.earned || {};
  const rows = Object.entries(inv).map(([gid,c]) => ({g:S.games.find(x=>x.id===gid), c})).filter(x=>x.g).sort((a,b)=>b.c-a.c);
  const mine = (ME.my_games||[]).map(id=>S.games.find(x=>x.id===id)).filter(Boolean);
  const tile = (v,l,c="") => `<div class="tile ${c}"><b class="num">${fmt(v)}</b><span>${esc(l)}</span></div>`;
  el.innerHTML = `<div class="pagehead"><div><h1>${esc(t("profileTitle"))}</h1><p>${esc(t("profileLead"))}</p></div></div>
    <div class="box">${accountCard()}
      <div class="ptiles">
        ${tile(ME.allowance ?? 0, t("startCoins"))}${tile(ME.invested_total ?? 0, t("investedNow"), "amber")}
        ${(ME.my_games||[]).length || ME.earned_total ? tile(ME.earned_total ?? 0, t("earnedTotal"), "cyan") : ""}
      </div>
      ${ME.raw_balance < 0 ? `<p class="note owed" style="margin:14px 0 0">${esc(t("owed",{n:fmt(-ME.raw_balance)}))}</p>` : ""}
    </div>
    <div class="box">
      <h2>${esc(t("portfolio"))}</h2>
      <p>${esc(t("portfolioLead",{f:fee}))}</p>
      ${rows.length ? `<div class="plist">${rows.map(({g,c}) => `<div class="prow">
          <div class="mini">${art(g)}</div>
          <div style="min-width:0"><b>${esc(g.title)}</b><small>${esc(g.cls)} · <span class="amt">${fmt(c)} ${esc(t("coins"))}</span></small></div>
          <div class="pbtns"><a class="btn play" href="#play" data-play="${g.id}">${I.play}${esc(t("play"))}</a>
            ${c>fee ? `<button class="btn ghost" data-withdraw="${g.id}">${esc(t("withdraw"))}</button>` : `<span class="hint">${esc(t("keptFee"))}</span>`}</div>
        </div>`).join("")}</div>` : `<p class="hint">${esc(t("noInv"))}</p><button class="btn primary" data-go="gallery">${esc(t("goGallery"))}</button>`}
    </div>
    ${mine.length ? `<div class="box"><h2>${esc(t("myGames"))}</h2><p>${esc(t("myGamesLead"))}</p>
      <div class="plist">${mine.map(g => `<div class="prow">
          <div class="mini">${art(g)}</div>
          <div style="min-width:0"><b>${esc(g.title)}</b><small>${fmt(g.coins)} ${esc(t("coins"))} · ${esc(g.investors===1?t("investor1"):t("investorsN",{n:g.investors}))}</small></div>
          <div class="pbtns"><span class="amt">+${fmt(earned[g.id]||0)} ${esc(t("coins"))}</span></div>
        </div>`).join("")}</div></div>` : ""}
    <div class="formfoot"><button class="btn ghost" data-signout>${esc(t("signOut"))}</button><span></span></div>`;
}
document.addEventListener("click", e => { const w = e.target.closest("[data-withdraw]"); if(w) openWithdraw(w.dataset.withdraw); });
function openWithdraw(gid){
  const g = S.games.find(x=>x.id===gid); if(!g || !ME) return;
  const c = (ME.invested||{})[gid] || 0, fee = FEE(), back = c - fee;
  if(back <= 0){ toast(t("nothingToWithdraw",{f:fee})); return; }
  const ov = modal(t("withdrawTitle",{g:g.title}), `
    <div class="account"><div class="me"><div class="mini" style="width:96px;height:54px">${art(g)}</div><div><b>${esc(g.title)}</b><span>${esc(t("youHaveIn",{n:fmt(c)}))}</span></div></div></div>
    <p class="note" style="margin:0">${esc(t("withdrawExplain",{b:fmt(back), f:fee}))}</p>
    <span class="hint err" id="wderr"></span>
    <div class="formfoot"><button type="button" class="btn ghost" data-close>${esc(t("cancel"))}</button><button class="btn invest" id="wdgo">${esc(t("withdrawGo",{b:fmt(back)}))}</button></div>`);
  ov.querySelector("#wdgo").onclick = async ev => {
    const btn = ev.currentTarget; busy(btn, true);
    const res = await api("withdraw", {p_token: token, p_game: gid});
    busy(btn, false);
    if(res.error){ ov.querySelector("#wderr").textContent = errText(res); return; }
    setMe(res); closeModal(); toast(t("withdrawn",{b:fmt(res.refund), g:g.title})); await refresh(); render();
  };
}

/* ---------- image helper: shrink any picture to a 16:9 thumbnail ---------- */
function readThumb(file){
  return new Promise((res, rej) => {
    if(!file || !file.type.startsWith("image/")) return rej();
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const W = 640, H = 360, c = document.createElement("canvas"); c.width = W; c.height = H;
      const x = c.getContext("2d"), s = Math.max(W/img.width, H/img.height);
      x.fillStyle = "#131c38"; x.fillRect(0,0,W,H);
      x.drawImage(img, (W-img.width*s)/2, (H-img.height*s)/2, img.width*s, img.height*s);
      URL.revokeObjectURL(url); res(c.toDataURL("image/jpeg", .8));
    };
    img.onerror = rej; img.src = url;
  });
}
function validLink(raw){
  let u = String(raw||"").trim(); if(!u) return null;
  if(!/^https?:\/\//i.test(u)) u = "https://"+u;
  try{ const p = new URL(u); if(p.protocol!=="https:" && p.protocol!=="http:") return null;
    if(!/\.netlify\.app$/i.test(p.hostname)) return null;
    p.protocol = "https:"; return p.href.replace(/\/$/,""); }catch(e){ return null; }
}

/* ---------- upload tab ---------- */
const draft = {thumb:""};
function renderUpload(){
  const el = $("#p-upload");
  el.innerHTML = `<div class="pagehead"><div><h1>${esc(t("upTitle"))}</h1><p>${esc(t("upLead"))}</p></div></div>
  <form class="box" id="uf" novalidate>
    <div class="fields">
      <div class="field"><label for="u1">${esc(t("s1"))}<span class="req">${esc(t("must"))}</span></label><input id="u1" autocomplete="off" autocapitalize="characters" placeholder="${esc(t("snumPh"))}"><span class="hint" id="u1m">${esc(t("findMe"))}</span></div>
      <div class="field"><label for="u2">${esc(t("s2"))}<span class="opt">${esc(t("optional"))}</span></label><input id="u2" autocomplete="off" autocapitalize="characters" placeholder="${esc(t("snumPh"))}"><span class="hint" id="u2m"></span></div>
      <div class="field"><label for="uemail">${esc(t("email"))}<span class="opt">${esc(t("optional"))}</span></label><input id="uemail" type="email" inputmode="email"><span class="hint">${esc(t("emailHint"))}</span></div>
      <div class="field"><label for="uteam">${esc(t("teamName"))}<span class="opt">${esc(t("optional"))}</span></label><input id="uteam" maxlength="60"></div>
      <div class="field full"><label for="utitle">${esc(t("gameName"))}<span class="req">${esc(t("must"))}</span></label><input id="utitle" maxlength="80"></div>
      <div class="field full"><label for="udesc">${esc(t("shortDesc"))}<span class="opt">${esc(t("optional"))}</span></label><textarea id="udesc" maxlength="400"></textarea></div>
      <div class="field full"><label>${esc(t("thumbnail"))}<span class="opt">${esc(t("optional"))}</span></label>
        <div class="thumbpick"><div class="prev" id="uprev"></div><div style="display:flex;flex-direction:column;gap:6px;min-width:0"><span class="btn ghost filebtn">${I.image}${esc(t("chooseImg"))}<input id="uthumb" type="file" accept="image/*" aria-label="${esc(t("chooseImg"))}"></span><span class="hint">${esc(t("thumbHint"))}</span></div></div></div>
      <div class="field full"><div class="linkrow"><div class="field"><label for="ulink">${esc(t("gameLink"))}<span class="req">${esc(t("must"))}</span></label><input id="ulink" inputmode="url" placeholder="${esc(t("linkPh"))}"><span class="hint" id="ulm"></span></div><div class="qr" id="uqr" aria-hidden="true"></div></div></div>
    </div>
    <span class="hint err" id="uerr"></span>
    <div class="formfoot"><span></span><button class="btn primary" id="ugo">${esc(t("submitGame"))}</button></div>
  </form>
  <div class="box csvbox">
    <div class="csvic">${I.file}</div>
    <div style="flex:1 1 260px;min-width:0"><h2>${esc(t("csvBoxTitle"))}</h2><p>${esc(t("csvBoxLead"))}</p></div>
    <button type="button" class="btn invest" id="csvBtn">${I.lock}${esc(t("csvBoxBtn"))}</button>
  </div>`;
  const f = el.querySelector("#uf");
  const found = {u1:null, u2:null};
  const prev = () => { el.querySelector("#uprev").innerHTML = art({id:"new", title: f.querySelector("#utitle").value || "?", thumbData: draft.thumb, students:[found.u1, found.u2].filter(Boolean).map(x=>({n:x.name}))}); };
  prev();
  for(const id of ["u1","u2"]){
    const inp = f.querySelector("#"+id), m = f.querySelector("#"+id+"m");
    inp.addEventListener("input", async () => {
      found[id] = null; m.className = "hint"; m.textContent = id==="u1" ? t("findMe") : ""; prev();
      const v = inp.value; if(!/^S\d{6}$/.test(normS(v))) return;
      const r = await api("lookup_student", {p_s: v}); if(v!==inp.value) return;
      if(r.error){ m.textContent = errText(r); m.className = "hint err"; return; }
      if(!/^8/.test(r.cls)){ m.textContent = t("notG8"); m.className = "hint err"; return; }
      found[id] = r; m.textContent = t("found",{n:r.name, c:r.cls}); m.className = "hint ok"; prev();
    });
  }
  f.querySelector("#utitle").addEventListener("input", prev);
  f.querySelector("#uthumb").addEventListener("change", async e => { try{ draft.thumb = await readThumb(e.target.files[0]); prev(); }catch(_){} });
  const link = f.querySelector("#ulink");
  link.addEventListener("input", () => { const u = validLink(link.value); f.querySelector("#uqr").innerHTML = u ? qrSvg(u) : ""; f.querySelector("#ulm").textContent = link.value && !u ? t("badLink") : ""; f.querySelector("#ulm").className = "hint err"; });
  el.querySelector("#csvBtn").onclick = () => askAdmin(openCSV);
  f.addEventListener("submit", async e => {
    e.preventDefault();
    const err = f.querySelector("#uerr"); err.textContent = "";
    const title = f.querySelector("#utitle").value.trim(), url = validLink(link.value);
    if(!found.u1){ err.textContent = t("needS1"); f.querySelector("#u1").focus(); return; }
    if(!title){ err.textContent = t("needTitle"); f.querySelector("#utitle").focus(); return; }
    if(!url){ err.textContent = t("badLink"); link.focus(); return; }
    const args = {p_s1: found.u1.s, p_s2: found.u2 ? found.u2.s : "", p_email: f.querySelector("#uemail").value.trim(),
      p_team: f.querySelector("#uteam").value.trim(), p_title: title, p_desc: f.querySelector("#udesc").value.trim(), p_url: url, p_thumb: draft.thumb, p_rules_ok: true};
    rulesCheck(async () => {
      const btn = f.querySelector("#ugo"); busy(btn, true);
      const res = await api("upload_game", args);
      busy(btn, false);
      if(res.error){ err.textContent = errText(res); return; }
      draft.thumb = ""; toast(t("added")); view.gallery = {q:"", cls:"", page:1, ids:null};
      await refresh(); go("gallery");
    });
  });
}

/* ---------- edit a game ---------- */
function openEdit(gid){
  const g = S.games.find(x=>x.id===gid); if(!g) return;
  const ov = modal(t("editTitle"), `<div class="account"><div class="me"><div class="mini" style="width:96px;height:54px">${art(g)}</div><div><b>${esc(g.title)}</b><span>${esc(g.cls)}</span></div></div></div>
    <p class="hint" style="margin:0">${esc(t("whoEdits"))}</p>
    <div class="choice small">
      <button data-ew="student"><span class="ic">${I.student}</span><b>${esc(t("student"))}</b><span>${esc(t("editStudentSub"))}</span></button>
      <button data-ew="admin"><span class="ic">${I.lock}</span><b>${esc(t("admin"))}</b><span>${esc(t("editAdminSub"))}</span></button>
    </div>`);
  ov.querySelector('[data-ew="admin"]').onclick = () => askAdmin(async code => {
    const full = await api("admin_get_game", {p_code: code, p_game: g.id});
    if(full.error){ toast(errText(full)); return; }
    editForm(g, {admin:true, code, full});
  });
  ov.querySelector('[data-ew="student"]').onclick = () => {
    const o2 = modal(t("editTitle"), `<form id="ef" class="field"><label for="eid">${esc(t("editAsk"))}</label><input id="eid" autocomplete="off" autocapitalize="characters" placeholder="${esc(t("snumPh"))}"><span class="hint err" id="eerr"></span>
      <div class="formfoot"><button type="button" class="btn ghost" data-close>${esc(t("cancel"))}</button><button class="btn primary">${esc(t("continue"))}</button></div></form>`);
    o2.querySelector("#ef").addEventListener("submit", async e => {
      e.preventDefault();
      const s = normS(o2.querySelector("#eid").value), btn = o2.querySelector("#ef .btn.primary");
      busy(btn, true); const res = await api("student_edit_game", {p_s: s, p_game: g.id, p_title: null, p_team: null, p_desc: null, p_thumb: null, p_thumb_set: false, p_rules_ok: false}); busy(btn, false);
      if(res.ok) return editForm(g, {admin:false, s});
      o2.querySelector("#eerr").textContent = errText(res);
    });
  };
}
function editForm(g, {admin, code, s, full}){
  let thumb = null;                                  // null = unchanged, "" = removed, data URL = new
  const cur = () => thumb===null ? (thumbs.get(g.id)?.data || "") : thumb;
  const st = admin ? [...full.students, {s:"",n:""}, {s:"",n:""}].slice(0, Math.max(3, full.students.length)) : [];
  const ov = modal(t("editTitle")+" · "+g.title, `
    ${admin?"":`<div class="note">${esc(t("studentEditNote"))}</div>`}
    <div class="field"><label>${esc(t("thumbnail"))}</label><div class="thumbpick"><div class="prev" id="eprev">${art(g)}</div>
      <div style="display:flex;flex-direction:column;gap:6px;min-width:0"><span class="btn ghost filebtn">${I.image}${esc(t("chooseImg"))}<input id="ethumb" type="file" accept="image/*" aria-label="${esc(t("chooseImg"))}"></span><button type="button" class="adminlink" id="eclear">${I.x}${esc(t("removePic"))}</button></div></div></div>
    <div class="fields">
      <div class="field full"><label for="etitle">${esc(t("gameName"))}</label><input id="etitle" maxlength="80" value="${esc(g.title)}"></div>
      <div class="field${admin?"":" full"}"><label for="eteam">${esc(t("teamName"))}</label><input id="eteam" maxlength="60" value="${esc(g.team)}"></div>
      ${admin?`<div class="field"><label for="ecls">${esc(t("cls"))}</label><input id="ecls" maxlength="4" value="${esc(g.cls)}"></div>`:""}
      <div class="field full"><label for="edesc">${esc(t("shortDesc"))}</label><textarea id="edesc" maxlength="400">${esc(g.desc)}</textarea></div>
    </div>
    ${admin?`<div class="fields">
      <div class="field full"><label for="elink">${esc(t("gameLink"))}</label><input id="elink" value="${esc(full.url)}"></div>
      ${full.email?`<div class="field full"><label>${esc(t("email"))}</label><input value="${esc(full.email)}" readonly></div>`:""}
      ${st.map((x,i)=>`<div class="field"><label for="es${i}">${esc(t("snum"))} ${i+1}</label><input id="es${i}" data-si="${i}" value="${esc(x.s)}" placeholder="${esc(t("snumPh"))}" autocomplete="off"><span class="hint" id="esm${i}">${esc(x.n)}</span></div>`).join("")}
    </div>`:""}
    <span class="hint err" id="eerr2"></span>
    <div class="formfoot">${admin?`<button type="button" class="btn danger" id="edel">${esc(t("deleteGame"))}</button>`:"<span></span>"}<button class="btn primary" id="esave">${esc(t("saveChanges"))}</button></div>`, {wide:true});
  const showPrev2 = () => { const d = cur(); ov.querySelector("#eprev").innerHTML = d ? `<img src="${esc(d)}" alt="">` : `<div class="initial n${initialsOf(g).length}" style="background:${grad(g.id+g.title)}">${esc(initialsOf(g))}</div>`; };
  ov.querySelector("#ethumb").addEventListener("change", async e => { try{ thumb = await readThumb(e.target.files[0]); showPrev2(); }catch(_){} });
  ov.querySelector("#eclear").addEventListener("click", () => { thumb = ""; showPrev2(); });
  if(admin){
    ov.querySelectorAll("[data-si]").forEach(inp => inp.addEventListener("input", async () => {
      const i = +inp.dataset.si, m = ov.querySelector("#esm"+i), v = inp.value; m.className="hint"; m.textContent = "";
      if(!v.trim()) return;
      if(!/^S\d{6}$/.test(normS(v))) return;
      const r = await api("lookup_student", {p_s: v}); if(v!==inp.value) return;
      if(r.error){ m.textContent = t("notFound"); m.className = "hint err"; return; }
      m.textContent = r.name+" · "+r.cls; m.className = "hint ok";
    }));
    ov.querySelector("#edel").onclick = () => askAdmin(async c2 => {
      const res = await api("admin_delete_game", {p_code: c2, p_game: g.id});
      if(res.error){ toast(errText(res)); return; }
      toast(t("deleted")); await refresh(); render();
    }, t("deleteAsk"));
  }
  ov.querySelector("#esave").onclick = async () => {
    const err = ov.querySelector("#eerr2"), btn = ov.querySelector("#esave");
    const title = ov.querySelector("#etitle").value.trim(); if(!title){ err.textContent = t("needTitle"); return; }
    let res;
    busy(btn, true);
    if(admin){
      const url = validLink(ov.querySelector("#elink").value);
      if(!url){ busy(btn, false); err.textContent = t("badLink"); return; }
      const students = st.map((x,i) => { const typed = normS(ov.querySelector("#es"+i).value);
        if(typed) return {s: typed}; if(!x.s && x.n) return {s:"", n:x.n}; return null; }).filter(Boolean);
      res = await api("admin_edit_game", {p_code: code, p_game: g.id, p_title: title, p_team: ov.querySelector("#eteam").value.trim(), p_cls: ov.querySelector("#ecls").value.trim(),
        p_desc: ov.querySelector("#edesc").value.trim(), p_url: url, p_students: students, p_thumb: thumb ?? "", p_thumb_set: thumb!==null});
    } else {
      busy(btn, false);
      const args = {p_s: s, p_game: g.id, p_title: title, p_team: ov.querySelector("#eteam").value.trim(), p_desc: ov.querySelector("#edesc").value.trim(), p_thumb: thumb ?? "", p_thumb_set: thumb!==null, p_rules_ok: true};
      const pic = thumb;
      return rulesCheck(async () => {
        const r2 = await api("student_edit_game", args);
        if(r2.error){ toast(errText(r2)); return; }
        if(pic!==null){ if(pic) thumbs.set(g.id, {v:-1, data:pic}); else thumbs.delete(g.id); }
        toast(t("saved")); await refresh(); softRender();
      });
    }
    busy(btn, false);
    if(res.error){ err.textContent = errText(res) + (res.s ? " ("+res.s+")" : ""); return; }
    if(thumb!==null){ if(thumb) thumbs.set(g.id, {v:-1, data:thumb}); else thumbs.delete(g.id); }
    closeModal(); toast(t("saved")); await refresh(); softRender();
  };
}

/* ---------- CSV import (admin) ---------- */
function parseCSV(text){
  const rows = []; let row = [], cell = "", q = false;
  for(let i=0;i<text.length;i++){
    const c = text[i];
    if(q){ if(c==='"'){ if(text[i+1]==='"'){ cell+='"'; i++; } else q=false; } else cell+=c; }
    else if(c==='"') q = true;
    else if(c===','){ row.push(cell); cell=""; }
    else if(c==='\n'||c==='\r'){ if(c==='\r'&&text[i+1]==='\n') i++; row.push(cell); rows.push(row); row=[]; cell=""; }
    else cell+=c;
  }
  if(cell||row.length){ row.push(cell); rows.push(row); }
  return rows.filter(r=>r.some(x=>x.trim()));
}
function csvRows(text){
  const rows = parseCSV(text.replace(/^﻿/,"")); if(rows.length<2) return [];
  const h = rows[0].map(x=>x.toLowerCase());
  const col = (...keys) => h.findIndex(x=>keys.some(k=>x.includes(k)));
  const C = {cls:col("section","class"), team:col("team","company"), title:col("title","game name"), desc:col("description"), url:col("link","url")};
  // "Student 1" may be split over a name column and an S-number column: join them
  const all = key => h.map((x,i)=>x.includes(key)?i:-1).filter(i=>i>=0);
  const S1 = all("student 1"), S2 = all("student 2");
  return rows.slice(1).map(r => ({...Object.fromEntries(Object.entries(C).map(([k,i]) => [k, i>=0 ? (r[i]||"") : ""])),
    s1: S1.map(i=>r[i]||"").join(" ").trim(), s2: S2.map(i=>r[i]||"").join(" ").trim()}));
}
function openCSV(code){
  const ov = modal(t("csvTitle"), `<p class="hint" style="margin:0">${esc(t("csvLead"))}</p>
    <span class="btn ghost filebtn">${I.file}${esc(t("csvChoose"))}<input id="csvf" type="file" accept=".csv,text/csv" aria-label="${esc(t("csvChoose"))}"></span>
    <div id="csvres"></div>`);
  ov.querySelector("#csvf").addEventListener("change", async e => {
    const file = e.target.files[0]; if(!file) return;
    const rows = csvRows(await file.text());
    const box = ov.querySelector("#csvres");
    const res = await api("admin_import", {p_code: code, p_rows: rows, p_dry_run: true});
    if(res.error){ box.innerHTML = `<div class="note">${esc(errText(res))}</div>`; return; }
    box.innerHTML = `<div class="note">${esc(t("csvReady",{n:res.added, d:res.dup, b:res.bad}))}${res.no_s?"<br>"+esc(t("csvNoS",{n:res.no_s})):""}</div>
      ${res.added?`<div class="formfoot"><span></span><button class="btn primary" id="csvgo">${esc(t("csvImport",{n:res.added}))}</button></div>`:""}`;
    box.querySelector("#csvgo")?.addEventListener("click", async ev => {
      busy(ev.currentTarget, true);
      const r2 = await api("admin_import", {p_code: code, p_rows: rows, p_dry_run: false});
      if(r2.error){ toast(errText(r2)); return; }
      closeModal(); toast(t("csvDone",{n:r2.added})); await refresh(); go("gallery");
    });
  });
}

/* ---------- admin settings ---------- */
let resetArmed = false;
async function openSettings(code){
  const info = await api("admin_stats", {p_code: code});
  if(info.error){ toast(errText(info)); return; }
  const st = info.settings;
  const ov = modal(t("setTitle"), `<div class="settings mbody" style="padding:0">
    <button class="btn primary" id="statsBtn" style="align-self:flex-start">${I.chart}${esc(t("stats"))}</button>
    <h3>${esc(t("visitorsTitle"))}</h3>
    <p class="hint" style="margin:0">${esc(t(st.visitors_open?"visitorsOpenNow":"visitorsLockedNow"))}</p>
    <div class="stack"><button class="btn ${st.visitors_open?"ghost toggleon":"invest"}" id="vToggle">${st.visitors_open?I.lock+esc(t("lockVisitors")):I.family+esc(t("openVisitors"))}</button></div>
    <h3>${esc(t("allowances"))}</h3>
    <div class="stack">
      <div class="field"><label for="sc">${esc(t("studentsLbl"))}</label><input id="sc" type="number" min="0" step="1" value="${st.student_coins}"></div>
      <div class="field"><label for="vc">${esc(t("visitorsLbl"))}</label><input id="vc" type="number" min="0" step="1" value="${st.visitor_coins}"></div>
      <button class="btn primary" id="saveAllow">${esc(t("saveAllow"))}</button>
    </div>
    ${st.student_bonus||st.visitor_bonus?`<p class="hint" style="margin:0">${esc(t("bonusNow",{s:st.student_bonus, v:st.visitor_bonus}))}</p>`:""}
    <h3>${esc(t("replenish"))}</h3>
    <div class="stack">
      <div class="field"><label for="ra">${esc(t("replAmount"))}</label><input id="ra" type="number" min="1" step="1" value="50"></div>
      <div class="field"><label for="rt">${esc(t("replTo"))}</label><select id="rt"><option value="all">${esc(t("everyone"))}</option><option value="student">${esc(t("studentsLbl"))}</option><option value="visitor">${esc(t("visitorsLbl"))}</option></select></div>
      <button class="btn invest" id="give">${I.coin}${esc(t("give"))}</button>
    </div>
    <h3>${esc(t("changeCode"))}</h3>
    <div class="stack">
      <div class="field"><label for="nc">${esc(t("newCode"))}</label><input id="nc" type="password" inputmode="numeric" maxlength="12" autocomplete="new-password"></div>
      <button class="btn ghost" id="setCode">${esc(t("saveCode"))}</button>
    </div>
    <h3>${esc(t("startFresh"))}</h3>
    <p class="hint" style="margin:0">${esc(t("startFreshLead"))}</p>
    <div class="stack"><button class="btn danger" id="resetCoins">${esc(t("resetCoinsBtn"))}</button></div>
    <p class="hint" style="margin:0">${esc(t("clearAllLead"))}</p>
    <div class="stack"><button class="btn ghost" id="clearAll">${esc(t("clearBtn"))}</button></div>
  </div>`, {wide:true});
  ov.querySelector("#statsBtn").onclick = () => openStats(code);
  ov.querySelector("#vToggle").onclick = async () => {
    const res = await api("admin_visitors", {p_code: code, p_open: !st.visitors_open});
    if(res.error) return toast(errText(res));
    toast(t(res.visitors_open?"visitorsOpened":"visitorsLockedToast")); await refresh(); openSettings(code);
  };
  ov.querySelector("#saveAllow").onclick = async () => {
    const res = await api("admin_settings", {p_code: code, p_student: Math.floor(+ov.querySelector("#sc").value||0), p_visitor: Math.floor(+ov.querySelector("#vc").value||0)});
    if(res.error) return toast(errText(res));
    toast(t("saved")); await refresh(); await loadMe(); softRender();
  };
  ov.querySelector("#give").onclick = async () => {
    const n = Math.floor(+ov.querySelector("#ra").value||0); if(n<1) return;
    const to = ov.querySelector("#rt").value;
    const res = await api("admin_replenish", {p_code: code, p_amount: n, p_target: to});
    if(res.error) return toast(errText(res));
    toast(t("gave",{n, w: to==="all"?t("everyone"):to==="student"?t("studentsLbl"):t("visitorsLbl")})); await refresh(); await loadMe(); softRender();
  };
  ov.querySelector("#setCode").onclick = async () => {
    const res = await api("admin_set_code", {p_code: code, p_new: ov.querySelector("#nc").value.trim()});
    if(res.error) return toast(errText(res));
    code = ov.querySelector("#nc").value.trim(); ov.querySelector("#nc").value = ""; toast(t("codeSaved"));
  };
  let coinsArmed = false;
  ov.querySelector("#resetCoins").onclick = async e => {
    if(!coinsArmed){ coinsArmed = true; e.target.textContent = t("resetSure"); return; }
    coinsArmed = false;
    const res = await api("admin_reset_coins", {p_code: code});
    if(res.error) return toast(errText(res));
    closeModal(); toast(t("coinsReset")); await refresh(); await loadMe(); render();
  };
  ov.querySelector("#clearAll").onclick = async e => {
    if(!resetArmed){ resetArmed = true; e.target.textContent = t("resetSure"); return; }
    resetArmed = false;
    const res = await api("admin_clear_activity", {p_code: code});
    if(res.error) return toast(errText(res));
    closeModal(); ME = null; token = null; store.set(KEY+"-token", null); toast(t("cleared")); await refresh(); render();
  };
}
async function openStats(code){
  const s = await api("admin_stats", {p_code: code});
  if(s.error){ toast(errText(s)); return; }
  const tile = (v,l,c="") => `<div class="tile ${c}"><b class="num">${fmt(v)}</b><span>${esc(l)}</span></div>`;
  const ov = modal(t("stats"), `<div class="tiles">
      ${tile(s.visitors, t("stVisitors"))}${tile(s.students, t("stStudents"))}
      ${tile(s.games, t("stGames"))}${tile(s.makers, t("stMakers"))}
      ${tile(s.given, t("stGiven"), "amber")}${tile(s.invested, t("stInvested"), "amber")}
      ${tile(s.earned, t("stEarned"), "cyan")}${tile(s.withdrawals, t("stWithdrawals"))}
      ${tile(Math.max(0, s.given + s.earned - s.invested), t("stLeft"))}${tile(s.likes, t("likes"), "cyan")}
    </div>
    <div class="formfoot"><button class="btn ghost" id="stBack">${lang==="ar"?"→":"←"} ${esc(t("setTitle"))}</button><button class="btn primary" data-close>${esc(t("close"))}</button></div>`, {wide:true});
  ov.querySelector("#stBack").onclick = () => openSettings(code);
}
$("#gearBtn").addEventListener("click", () => { resetArmed = false; askAdmin(openSettings); });

/* ---------- language ---------- */
function applyLang(){
  document.documentElement.lang = lang; document.documentElement.dir = lang==="ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-t]").forEach(el => el.textContent = t(el.dataset.t));
  document.querySelectorAll("[data-tp]").forEach(el => el.placeholder = t(el.dataset.tp));
  $("#langBtn").setAttribute("aria-label", lang==="ar" ? "English" : "العربية");
  document.title = t("appName");
}
$("#langBtn").addEventListener("click", () => { lang = lang==="ar" ? "en" : "ar"; store.set(KEY+"-lang", lang); applyLang(); render(); });

/* ---------- header wallet ---------- */
function renderWallet(){
  const w = $("#wallet");
  if(!ME){ w.hidden = true; return; }
  w.hidden = false;
  w.innerHTML = `${I.coin}<span class="wl">${esc(t("wallet",{n:fmt(ME.balance)}))}</span><span class="num ws">${fmt(ME.balance)}</span>`;
  w.querySelector(".ws").hidden = !matchMedia("(max-width:920px)").matches;
  w.onclick = () => go("profile");
}

/* Full render on tab change; soft render keeps forms and the playing game untouched */
function render(){
  renderWallet();
  if(tab==="gallery") renderGallery();
  if(tab==="rankings") renderRankings();
  if(tab==="invest") renderInvest();
  if(tab==="upload") renderUpload();
  if(tab==="profile") renderProfile();
  if(tab==="play") renderPlay();
}
function softRender(){
  renderWallet();
  if(tab==="gallery") renderGallery();
  if(tab==="rankings") renderRankings();
  if(tab==="profile") renderProfile();
}
async function refresh(){ const ok = await loadState(); softRender(); return ok; }
addEventListener("resize", renderWallet);

applyLang();
go(tab);
(async () => {
  if(!CONFIGURED){ render(); return; }
  await Promise.all([loadState(), loadMe()]);
  render();
  // keep numbers live for everyone at the exhibition
  setInterval(async () => { if(document.visibilityState==="visible" && tab!=="play"){ await loadState(); if(ME) await loadMe(); softRender(); } }, 30000);
  document.addEventListener("visibilitychange", () => { if(document.visibilityState==="visible") refresh(); });
})();
addEventListener("load", () => { if(tab==="gallery"||tab==="upload") softRender(); });
})();
