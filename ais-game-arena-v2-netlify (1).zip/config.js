// ======================================================================
// AI Game Arena · connection settings
// Paste your two values from Supabase → Project Settings → API (or "Connect"):
//   SUPABASE_URL      = the Project URL, like https://abcdefghijk.supabase.co
//   SUPABASE_ANON_KEY = the "anon public" key (a long code starting eyJ...)
//                       or the newer "publishable" key (starts sb_publishable_...)
// Both are safe to be public. Never paste the "service_role" or "secret" key here.
// ======================================================================
window.ARENA_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-KEY"
};
