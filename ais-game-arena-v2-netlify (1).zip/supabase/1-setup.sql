-- =====================================================================
-- AIS GAME ARENA · database setup for Supabase (version 2)
-- Run this whole file in Supabase → SQL Editor → New query → Run.
-- New database: it creates everything. Existing database: it upgrades it to
-- version 2 and keeps the student list, games, pictures and admin code.
--
-- How it is protected:
--   * Every table has Row Level Security switched on and NO public policies,
--     so the website cannot read or change tables directly.
--   * The website can only call the functions below. Each function checks
--     the rules (S-numbers, coin balance, own game, admin code) itself.
--   * S-numbers and the student list never leave the database except one
--     student at a time, when that exact S-number is typed.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------- tables ----------
create table if not exists public.settings (
  id            int primary key default 1 check (id = 1),
  student_coins int  not null default 300,
  visitor_coins int  not null default 100,
  student_bonus int  not null default 0,
  visitor_bonus int  not null default 0,
  admin_hash    text not null
);
insert into public.settings (id, admin_hash)
values (1, encode(extensions.digest('2627', 'sha256'), 'hex'))
on conflict (id) do nothing;

create table if not exists public.roster (
  s_number text primary key,          -- e.g. S123456
  name     text not null,
  cls      text not null              -- e.g. 8J
);

create table if not exists public.games (
  id         text primary key default ('g' || substr(md5(random()::text || clock_timestamp()::text), 1, 12)),
  cls        text not null,
  title      text not null,
  team       text not null default '',
  descr      text not null default '',
  url        text not null unique,
  email      text not null default '',
  thumb      text not null default '',
  thumb_v    int  not null default 0,
  students   jsonb not null default '[]'::jsonb,   -- [{"s":"S123456","n":"Omar Maher"}]; "s" may be "" for a name-only student
  created_at timestamptz not null default now()
);

create table if not exists public.accounts (
  id         text primary key,          -- 'S:S123456' for students, 'V:email' for visitors
  kind       text not null check (kind in ('student', 'visitor')),
  s_number   text,
  name       text not null,
  cls        text,
  email      text unique,
  token      uuid not null default gen_random_uuid(),
  created_at timestamptz not null default now()
);

create table if not exists public.investments (
  id         bigserial primary key,
  account_id text not null references public.accounts(id) on delete cascade,
  game_id    text not null references public.games(id) on delete cascade,
  coins      int  not null check (coins > 0),
  created_at timestamptz not null default now()
);
create index if not exists investments_game_idx    on public.investments(game_id);
create index if not exists investments_account_idx on public.investments(account_id);

create table if not exists public.likes (
  game_id text not null references public.games(id) on delete cascade,
  who     text not null,
  primary key (game_id, who)
);

create table if not exists public.admin_fails (at timestamptz not null default now());

-- ---------- version 2 additions (safe on an existing database) ----------
alter table public.settings    add column if not exists visitors_open boolean not null default false;  -- parents/visitors locked until admin opens
alter table public.settings    add column if not exists min_invest    int     not null default 20;
alter table public.settings    add column if not exists withdraw_fee  int     not null default 20;
alter table public.games       add column if not exists rules_ok_at   timestamptz;                      -- when the student ticked the rules checklist
alter table public.investments add column if not exists kind          text    not null default 'invest'; -- 'invest' or 'withdraw' (withdrawals are negative)
alter table public.investments drop constraint if exists investments_coins_check;
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'investments_coins_nonzero') then
    alter table public.investments add constraint investments_coins_nonzero check (coins <> 0);
  end if;
end $$;

-- Coins the makers of a game receive when someone invests in it (negative when an investor withdraws)
create table if not exists public.earnings (
  id            bigserial primary key,
  account_id    text   not null references public.accounts(id) on delete cascade,
  game_id       text   not null references public.games(id) on delete cascade,
  investment_id bigint references public.investments(id) on delete cascade,
  coins         int    not null,
  created_at    timestamptz not null default now()
);
create index if not exists earnings_account_idx on public.earnings(account_id);
create index if not exists earnings_game_idx    on public.earnings(game_id);

alter table public.settings    enable row level security;
alter table public.roster      enable row level security;
alter table public.games       enable row level security;
alter table public.accounts    enable row level security;
alter table public.investments enable row level security;
alter table public.likes       enable row level security;
alter table public.admin_fails enable row level security;
alter table public.earnings    enable row level security;
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;

-- ---------- helpers (not callable from the website) ----------
create or replace function public._norm_s(p text) returns text
language sql immutable as $$ select upper(regexp_replace(coalesce(p, ''), '\s', '', 'g')) $$;

create or replace function public._norm_title(p text) returns text
language sql immutable as $$ select lower(regexp_replace(coalesce(p, ''), '[^[:alnum:]]', '', 'g')) $$;

create or replace function public._clean(p text, maxlen int) returns text
language sql immutable as $$ select left(btrim(regexp_replace(coalesce(p, ''), '\s+', ' ', 'g')), maxlen) $$;

create or replace function public._allowance(p_kind text) returns int
language sql stable security definer set search_path = public as $$
  select case when p_kind = 'student' then student_coins + student_bonus else visitor_coins + visitor_bonus end
  from settings where id = 1
$$;

-- Allowance + coins earned from your own games - coins you have invested (withdrawals count back)
create or replace function public._raw_balance(p_account text) returns int
language sql stable security definer set search_path = public as $$
  select (_allowance(a.kind)
          + coalesce((select sum(coins) from earnings e where e.account_id = a.id), 0)
          - coalesce((select sum(coins) from investments i where i.account_id = a.id), 0))::int
  from accounts a where a.id = p_account
$$;

create or replace function public._balance(p_account text) returns int
language sql stable security definer set search_path = public as $$
  select greatest(0, _raw_balance(p_account))
$$;

-- Shares p_coins between the students who made the game (25 + 25 for a pair; the first name gets any odd coin).
-- Negative p_coins takes coins back the same way when an investor withdraws.
create or replace function public._pay_makers(p_game text, p_coins int, p_inv bigint) returns void
language plpgsql security definer set search_path = public as $$
declare makers text[]; n int; base int; rem int; i int; amt int; sgn int := sign(p_coins); total int := abs(p_coins);
begin
  select array_agg(r.s_number order by t.ord) into makers
  from games g, jsonb_array_elements(g.students) with ordinality t(s, ord)
  join roster r on r.s_number = t.s->>'s'
  where g.id = p_game;
  n := coalesce(array_length(makers, 1), 0);
  if n = 0 or total = 0 then return; end if;
  insert into accounts (id, kind, s_number, name, cls)
  select 'S:' || r.s_number, 'student', r.s_number, r.name, r.cls from roster r where r.s_number = any(makers)
  on conflict (id) do nothing;
  base := total / n; rem := total % n;
  for i in 1..n loop
    amt := sgn * (base + case when i <= rem then 1 else 0 end);
    if amt <> 0 then
      insert into earnings (account_id, game_id, investment_id, coins) values ('S:' || makers[i], p_game, p_inv, amt);
    end if;
  end loop;
end $$;

-- Returns NULL when the code is right, otherwise an error object.
-- After 8 wrong codes in 10 minutes, admin access pauses for 10 minutes.
create or replace function public._admin(p_code text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
begin
  delete from admin_fails where at < now() - interval '1 day';
  if (select count(*) from admin_fails where at > now() - interval '10 minutes') >= 8 then
    return jsonb_build_object('error', 'LOCKED');
  end if;
  if encode(digest(coalesce(p_code, ''), 'sha256'), 'hex') = (select admin_hash from settings where id = 1) then
    return null;
  end if;
  insert into admin_fails default values;
  return jsonb_build_object('error', 'WRONG_CODE');
end $$;

create or replace function public._valid_url(p text) returns text
language plpgsql immutable as $$
declare u text := btrim(coalesce(p, ''));
begin
  if u = '' then return null; end if;
  if u ~* 'domain=[a-z0-9-]+\.netlify\.app' then u := substring(u from '(?i)domain=([a-z0-9-]+\.netlify\.app)'); end if;   -- "edge-access" links
  if u !~* '^https?://' then u := 'https://' || u; end if;
  u := regexp_replace(u, '^http://', 'https://', 'i');
  u := regexp_replace(u, '/+$', '');
  if u !~* '^https://[a-z0-9]([a-z0-9-]*[a-z0-9])?\.netlify\.app(/[^\s<>"]*)?$' then return null; end if;
  return u;
end $$;

create or replace function public._valid_thumb(p text) returns boolean
language sql immutable as $$
  select p is null or p = '' or (length(p) <= 400000 and p ~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$')
$$;

create or replace function public._me(p_account text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'token', a.token, 'kind', a.kind, 'name', a.name, 'cls', a.cls, 'email', a.email,
    'balance', _balance(a.id), 'raw_balance', _raw_balance(a.id), 'allowance', _allowance(a.kind),
    'invested', coalesce((select jsonb_object_agg(game_id, total) from
                  (select game_id, sum(coins) as total from investments where account_id = a.id group by game_id having sum(coins) <> 0) x), '{}'::jsonb),
    'invested_total', coalesce((select sum(coins) from investments where account_id = a.id), 0),
    'earned', coalesce((select jsonb_object_agg(game_id, total) from
                  (select game_id, sum(coins) as total from earnings where account_id = a.id group by game_id) x), '{}'::jsonb),
    'earned_total', coalesce((select sum(coins) from earnings where account_id = a.id), 0),
    'my_games', case when a.kind = 'student' then
                  coalesce((select jsonb_agg(g.id) from games g where g.students @> jsonb_build_array(jsonb_build_object('s', a.s_number))), '[]'::jsonb)
                else '[]'::jsonb end)
  from accounts a where a.id = p_account
$$;

-- ---------- public reads ----------
create or replace function public.get_state(p_device text default '') returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'settings', (select jsonb_build_object('student', student_coins + student_bonus, 'visitor', visitor_coins + visitor_bonus,
                                           'visitors_open', visitors_open, 'min_invest', min_invest, 'withdraw_fee', withdraw_fee) from settings where id = 1),
    'games', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', g.id, 'cls', g.cls, 'title', g.title, 'team', g.team, 'desc', g.descr, 'url', g.url,
        'students', (select coalesce(jsonb_agg(jsonb_build_object('n', s->>'n')), '[]'::jsonb) from jsonb_array_elements(g.students) s),
        'thumb_v', case when g.thumb = '' then 0 else g.thumb_v end,
        'coins', coalesce(i.coins, 0), 'investors', coalesce(i.investors, 0), 'likes', coalesce(l.likes, 0),
        'liked', exists (select 1 from likes x where x.game_id = g.id and x.who = p_device and p_device <> ''),
        'created', g.created_at) order by g.created_at desc, g.id)
      from games g
      left join (select game_id, sum(net)::int as coins, (count(*) filter (where net > 0))::int as investors
                 from (select game_id, account_id, sum(coins) as net from investments group by game_id, account_id) n
                 group by game_id) i on i.game_id = g.id
      left join (select game_id, count(*)::int as likes from likes group by game_id) l on l.game_id = g.id
    ), '[]'::jsonb))
$$;

-- Everyone who has coins in a game, most coins first (names only, never emails)
create or replace function public.get_investors(p_game text) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('name', a.name, 'kind', a.kind, 'cls', a.cls, 'coins', x.net) order by x.net desc, x.first_at), '[]'::jsonb)
  from (select account_id, sum(coins)::int as net, min(created_at) as first_at
        from investments where game_id = p_game group by account_id having sum(coins) > 0) x
  join accounts a on a.id = x.account_id
$$;

create or replace function public.get_thumbs(p_ids text[]) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(id, thumb), '{}'::jsonb) from games where id = any(p_ids[1:60]) and thumb <> ''
$$;

create or replace function public.find_games(p_s text) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(id), '[]'::jsonb) from games
  where students @> jsonb_build_array(jsonb_build_object('s', _norm_s(p_s)))
$$;

create or replace function public.lookup_student(p_s text) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select jsonb_build_object('s', s_number, 'name', name, 'cls', cls) from roster where s_number = _norm_s(p_s)),
    jsonb_build_object('error', 'NOT_FOUND'))
$$;

-- ---------- sign in ----------
create or replace function public.student_login(p_s text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r roster;
begin
  select * into r from roster where s_number = _norm_s(p_s);
  if not found then return jsonb_build_object('error', 'NOT_FOUND'); end if;
  insert into accounts (id, kind, s_number, name, cls) values ('S:' || r.s_number, 'student', r.s_number, r.name, r.cls)
  on conflict (id) do nothing;
  return _me('S:' || r.s_number);
end $$;

create or replace function public.visitor_create(p_first text, p_last text, p_email text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e text := lower(btrim(coalesce(p_email, '')));
        f text := _clean(p_first, 40); l text := _clean(p_last, 40);
begin
  if not (select visitors_open from settings where id = 1) then return jsonb_build_object('error', 'VISITORS_LOCKED'); end if;
  if e !~ '^[^\s@]+@[^\s@]+\.[^\s@]{2,}$' or length(e) > 120 then return jsonb_build_object('error', 'BAD_EMAIL'); end if;
  if f = '' or l = '' then return jsonb_build_object('error', 'NEED_NAME'); end if;
  begin
    insert into accounts (id, kind, name, email) values ('V:' || e, 'visitor', f || ' ' || l, e);
  exception when unique_violation then
    return jsonb_build_object('error', 'EMAIL_TAKEN');
  end;
  return _me('V:' || e);
end $$;

create or replace function public.visitor_login(p_email text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e text := lower(btrim(coalesce(p_email, '')));
begin
  if not (select visitors_open from settings where id = 1) then return jsonb_build_object('error', 'VISITORS_LOCKED'); end if;
  if not exists (select 1 from accounts where id = 'V:' || e) then return jsonb_build_object('error', 'NO_ACCOUNT'); end if;
  return _me('V:' || e);
end $$;

create or replace function public.get_me(p_token uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a text;
begin
  select id into a from accounts where token = p_token;
  if a is null then return jsonb_build_object('error', 'NO_SESSION'); end if;
  return _me(a);
end $$;

-- ---------- invest + like ----------
create or replace function public.invest(p_token uuid, p_game text, p_coins int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a accounts; g games; st settings; bal int; new_id bigint;
begin
  select * into a from accounts where token = p_token for update;   -- one investment at a time per account
  if not found then return jsonb_build_object('error', 'NO_SESSION'); end if;
  select * into st from settings where id = 1;
  if a.kind = 'visitor' and not st.visitors_open then return jsonb_build_object('error', 'VISITORS_LOCKED'); end if;
  select * into g from games where id = p_game;
  if not found then return jsonb_build_object('error', 'NO_GAME'); end if;
  if a.kind = 'student' and g.students @> jsonb_build_array(jsonb_build_object('s', a.s_number)) then
    return jsonb_build_object('error', 'OWN_GAME');
  end if;
  if p_coins is null or p_coins < st.min_invest then return jsonb_build_object('error', 'MIN_INVEST', 'min', st.min_invest); end if;
  bal := _raw_balance(a.id);
  if p_coins > bal then return jsonb_build_object('error', 'NOT_ENOUGH', 'balance', greatest(bal, 0)); end if;
  insert into investments (account_id, game_id, coins, kind) values (a.id, g.id, p_coins, 'invest') returning id into new_id;
  perform _pay_makers(g.id, p_coins, new_id);
  return _me(a.id);
end $$;

-- Takes an investment back out of a game. The withdrawal fee (20 AI Coins) stays in the game.
create or replace function public.withdraw(p_token uuid, p_game text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare a accounts; st settings; pos int; refund int; new_id bigint;
begin
  select * into a from accounts where token = p_token for update;
  if not found then return jsonb_build_object('error', 'NO_SESSION'); end if;
  select * into st from settings where id = 1;
  if a.kind = 'visitor' and not st.visitors_open then return jsonb_build_object('error', 'VISITORS_LOCKED'); end if;
  select coalesce(sum(coins), 0) into pos from investments where account_id = a.id and game_id = p_game;
  refund := pos - st.withdraw_fee;
  if refund <= 0 then return jsonb_build_object('error', 'NOTHING_TO_WITHDRAW', 'fee', st.withdraw_fee); end if;
  insert into investments (account_id, game_id, coins, kind) values (a.id, p_game, -refund, 'withdraw') returning id into new_id;
  perform _pay_makers(p_game, -refund, new_id);
  return _me(a.id) || jsonb_build_object('refund', refund);
end $$;

create or replace function public.toggle_like(p_device text, p_game text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare d text := left(coalesce(p_device, ''), 64);
begin
  if d !~ '^[A-Za-z0-9_-]{6,64}$' then return jsonb_build_object('error', 'BAD_DEVICE'); end if;
  if not exists (select 1 from games where id = p_game) then return jsonb_build_object('error', 'NO_GAME'); end if;
  delete from likes where game_id = p_game and who = d;
  if not found then insert into likes (game_id, who) values (p_game, d); end if;
  return jsonb_build_object('liked', exists (select 1 from likes where game_id = p_game and who = d),
                            'likes', (select count(*) from likes where game_id = p_game));
end $$;

-- ---------- students: upload + edit ----------
create or replace function public.upload_game(p_s1 text, p_s2 text, p_email text, p_team text, p_title text,
                                              p_desc text, p_url text, p_thumb text, p_rules_ok boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r1 roster; r2 roster; u text := _valid_url(p_url); t text := _clean(p_title, 80); studs jsonb; new_id text;
begin
  select * into r1 from roster where s_number = _norm_s(p_s1);
  if not found then return jsonb_build_object('error', 'NEED_S1'); end if;
  if r1.cls !~ '^8' then return jsonb_build_object('error', 'NOT_G8'); end if;
  studs := jsonb_build_array(jsonb_build_object('s', r1.s_number, 'n', r1.name));
  if coalesce(btrim(p_s2), '') <> '' then
    select * into r2 from roster where s_number = _norm_s(p_s2);
    if not found then return jsonb_build_object('error', 'S2_NOT_FOUND'); end if;
    if r2.cls !~ '^8' then return jsonb_build_object('error', 'NOT_G8'); end if;
    if r2.s_number <> r1.s_number then studs := studs || jsonb_build_object('s', r2.s_number, 'n', r2.name); end if;
  end if;
  if t = '' then return jsonb_build_object('error', 'NEED_TITLE'); end if;
  if u is null then return jsonb_build_object('error', 'BAD_LINK'); end if;
  if exists (select 1 from games where lower(url) = lower(u)) then return jsonb_build_object('error', 'DUP_LINK'); end if;
  if exists (select 1 from games where cls = r1.cls and _norm_title(title) = _norm_title(t)) then return jsonb_build_object('error', 'DUP_TITLE'); end if;
  if not _valid_thumb(p_thumb) then return jsonb_build_object('error', 'BAD_IMAGE'); end if;
  if not coalesce(p_rules_ok, false) then return jsonb_build_object('error', 'RULES'); end if;
  insert into games (cls, title, team, descr, url, email, thumb, thumb_v, students, rules_ok_at)
  values (r1.cls, t, _clean(p_team, 60), _clean(p_desc, 400), u, left(lower(btrim(coalesce(p_email, ''))), 120),
          coalesce(p_thumb, ''), case when coalesce(p_thumb, '') = '' then 0 else 1 end, studs, now())
  returning id into new_id;
  return jsonb_build_object('ok', true, 'id', new_id);
end $$;

create or replace function public.student_edit_game(p_s text, p_game text, p_title text, p_team text, p_desc text,
                                                    p_thumb text, p_thumb_set boolean, p_rules_ok boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare g games; t text := _clean(p_title, 80);
begin
  select * into g from games where id = p_game for update;
  if not found then return jsonb_build_object('error', 'NO_GAME'); end if;
  if _norm_s(p_s) = '' or not (g.students @> jsonb_build_array(jsonb_build_object('s', _norm_s(p_s)))) then
    return jsonb_build_object('error', 'NOT_YOURS');
  end if;
  if p_title is null then return jsonb_build_object('ok', true); end if;   -- S-number check only
  if t = '' then return jsonb_build_object('error', 'NEED_TITLE'); end if;
  if p_thumb_set and not _valid_thumb(p_thumb) then return jsonb_build_object('error', 'BAD_IMAGE'); end if;
  if not coalesce(p_rules_ok, false) then return jsonb_build_object('error', 'RULES'); end if;
  update games set title = t, team = _clean(p_team, 60), descr = _clean(p_desc, 400), rules_ok_at = now(),
         thumb = case when p_thumb_set then coalesce(p_thumb, '') else thumb end,
         thumb_v = case when p_thumb_set then thumb_v + 1 else thumb_v end
  where id = g.id;
  return jsonb_build_object('ok', true);
end $$;

-- ---------- admin ----------
create or replace function public.admin_check(p_code text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin return coalesce(e, jsonb_build_object('ok', true)); end $$;

create or replace function public.admin_get_game(p_code text, p_game text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code); g games;
begin
  if e is not null then return e; end if;
  select * into g from games where id = p_game;
  if not found then return jsonb_build_object('error', 'NO_GAME'); end if;
  return jsonb_build_object('id', g.id, 'cls', g.cls, 'title', g.title, 'team', g.team, 'desc', g.descr, 'url', g.url,
                            'email', g.email, 'students', g.students);
end $$;

-- p_students: [{"s":"S123456"}] or [{"s":"","n":"Name only"}]
create or replace function public.admin_edit_game(p_code text, p_game text, p_title text, p_team text, p_cls text, p_desc text,
                                                  p_url text, p_students jsonb, p_thumb text, p_thumb_set boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code); u text := _valid_url(p_url); t text := _clean(p_title, 80);
        studs jsonb := '[]'::jsonb; x jsonb; r roster;
begin
  if e is not null then return e; end if;
  if not exists (select 1 from games where id = p_game) then return jsonb_build_object('error', 'NO_GAME'); end if;
  if t = '' then return jsonb_build_object('error', 'NEED_TITLE'); end if;
  if u is null then return jsonb_build_object('error', 'BAD_LINK'); end if;
  if exists (select 1 from games where id <> p_game and lower(url) = lower(u)) then return jsonb_build_object('error', 'DUP_LINK'); end if;
  if p_thumb_set and not _valid_thumb(p_thumb) then return jsonb_build_object('error', 'BAD_IMAGE'); end if;
  for x in select * from jsonb_array_elements(coalesce(p_students, '[]'::jsonb)) loop
    if coalesce(x->>'s', '') <> '' then
      select * into r from roster where s_number = _norm_s(x->>'s');
      if not found then return jsonb_build_object('error', 'NOT_FOUND', 's', x->>'s'); end if;
      if not studs @> jsonb_build_array(jsonb_build_object('s', r.s_number)) then
        studs := studs || jsonb_build_object('s', r.s_number, 'n', r.name);
      end if;
    elsif _clean(x->>'n', 80) <> '' then
      studs := studs || jsonb_build_object('s', '', 'n', _clean(x->>'n', 80));
    end if;
  end loop;
  if jsonb_array_length(studs) = 0 then return jsonb_build_object('error', 'NEED_S1'); end if;
  update games set title = t, team = _clean(p_team, 60), cls = coalesce(nullif(upper(_clean(p_cls, 4)), ''), cls),
         descr = _clean(p_desc, 400), url = u, students = studs,
         thumb = case when p_thumb_set then coalesce(p_thumb, '') else thumb end,
         thumb_v = case when p_thumb_set then thumb_v + 1 else thumb_v end
  where id = p_game;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_delete_game(p_code text, p_game text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  delete from games where id = p_game;
  return jsonb_build_object('ok', true);
end $$;

-- p_rows: [{"cls":"8L","s1":"Name S123456","s2":"...","team":"...","title":"...","desc":"...","url":"..."}]
create or replace function public.admin_import(p_code text, p_rows jsonb, p_dry_run boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code); row jsonb; u text; cls text; t text; studs jsonb; f text; m text[]; r roster;
        added int := 0; dup int := 0; bad int := 0; no_s int := 0;
begin
  if e is not null then return e; end if;
  create temp table if not exists _seen (k text primary key) on commit drop;
  truncate _seen;
  insert into _seen select 'u:' || lower(url) from games on conflict do nothing;
  insert into _seen select 't:' || g.cls || '|' || _norm_title(g.title) from games g on conflict do nothing;
  for row in select * from jsonb_array_elements(coalesce(p_rows, '[]'::jsonb)) loop
    u := _valid_url(row->>'url');
    if u is null then bad := bad + 1; continue; end if;
    cls := upper(_clean(row->>'cls', 4)); t := _clean(row->>'title', 80);
    if t = '' then t := 'Untitled game'; end if;
    if exists (select 1 from _seen where k in ('u:' || lower(u), 't:' || cls || '|' || _norm_title(t))) then dup := dup + 1; continue; end if;
    insert into _seen values ('u:' || lower(u)) on conflict do nothing;
    insert into _seen values ('t:' || cls || '|' || _norm_title(t)) on conflict do nothing;
    studs := '[]'::jsonb;
    foreach f in array array[coalesce(row->>'s1', ''), coalesce(row->>'s2', '')] loop
      if btrim(f) = '' then continue; end if;
      if f ~* 's\d{6}' then
        for m in select regexp_matches(f, '[sS]\d{6}', 'g') loop
          select * into r from roster where s_number = upper(m[1]);
          if found and not studs @> jsonb_build_array(jsonb_build_object('s', r.s_number)) then
            studs := studs || jsonb_build_object('s', r.s_number, 'n', r.name);
          end if;
        end loop;
      else
        studs := studs || jsonb_build_object('s', '', 'n', _clean(f, 80)); no_s := no_s + 1;
      end if;
    end loop;
    if jsonb_array_length(studs) = 0 then bad := bad + 1; continue; end if;
    if cls = '' then cls := coalesce((select cls from roster where s_number = studs->0->>'s'), ''); end if;
    -- same student already has a game with the same or a very similar name: keep the one in the arena
    if exists (select 1 from games g, jsonb_array_elements(studs) s
               where s->>'s' <> '' and g.students @> jsonb_build_array(jsonb_build_object('s', s->>'s'))
                 and (_norm_title(g.title) like '%' || _norm_title(t) || '%' or _norm_title(t) like '%' || _norm_title(g.title) || '%')) then
      dup := dup + 1; continue;
    end if;
    if not p_dry_run then
      insert into games (cls, title, team, descr, url, students)
      values (cls, t, _clean(row->>'team', 60), _clean(row->>'desc', 400), u, studs)
      on conflict (url) do nothing;
    end if;
    added := added + 1;
  end loop;
  return jsonb_build_object('added', added, 'dup', dup, 'bad', bad, 'no_s', no_s, 'dry_run', p_dry_run);
end $$;

create or replace function public.admin_settings(p_code text, p_student int, p_visitor int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  update settings set student_coins = greatest(0, least(coalesce(p_student, student_coins), 100000)),
                      visitor_coins = greatest(0, least(coalesce(p_visitor, visitor_coins), 100000)) where id = 1;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_replenish(p_code text, p_amount int, p_target text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  if p_amount is null or p_amount < 1 or p_amount > 100000 then return jsonb_build_object('error', 'BAD_AMOUNT'); end if;
  update settings set
    student_bonus = student_bonus + case when p_target in ('all', 'student') then p_amount else 0 end,
    visitor_bonus = visitor_bonus + case when p_target in ('all', 'visitor') then p_amount else 0 end
  where id = 1;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.admin_stats(p_code text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  return (select jsonb_build_object(
    'settings',  (select to_jsonb(s) - 'admin_hash' - 'id' from settings s where id = 1),
    'visitors',  (select count(*) from accounts where kind = 'visitor'),
    'students',  (select count(*) from accounts where kind = 'student'),
    'games',     (select count(*) from games),
    'makers',    (select count(distinct coalesce(nullif(s->>'s', ''), s->>'n')) from games, jsonb_array_elements(students) s),
    'given',     (select coalesce(sum(_allowance(kind)), 0) from accounts),
    'invested',  (select coalesce(sum(coins), 0) from investments),
    'earned',    (select coalesce(sum(coins), 0) from earnings),
    'withdrawals', (select count(*) from investments where kind = 'withdraw'),
    'likes',     (select count(*) from likes)));
end $$;

create or replace function public.admin_set_code(p_code text, p_new text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  if coalesce(p_new, '') !~ '^[0-9]{4,12}$' then return jsonb_build_object('error', 'BAD_CODE'); end if;
  update settings set admin_hash = encode(digest(p_new, 'sha256'), 'hex') where id = 1;
  return jsonb_build_object('ok', true);
end $$;

-- Puts every AI Coin back to the start: removes all investments and earnings and any extra coins given.
-- Games, pictures, descriptions, sign-ups and likes stay.
create or replace function public.admin_reset_coins(p_code text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  delete from earnings; delete from investments;
  update settings set student_bonus = 0, visitor_bonus = 0 where id = 1;
  return jsonb_build_object('ok', true);
end $$;

-- Opens or locks investing for parents and visitors (open it for the Parent-Teacher Meeting)
create or replace function public.admin_visitors(p_code text, p_open boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  update settings set visitors_open = coalesce(p_open, false) where id = 1;
  return jsonb_build_object('ok', true, 'visitors_open', coalesce(p_open, false));
end $$;

-- Clears coins, investments, likes and sign-ups (for example after a rehearsal). Games stay.
create or replace function public.admin_clear_activity(p_code text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare e jsonb := _admin(p_code);
begin
  if e is not null then return e; end if;
  delete from earnings; delete from investments; delete from likes; delete from accounts;
  update settings set student_bonus = 0, visitor_bonus = 0 where id = 1;
  return jsonb_build_object('ok', true);
end $$;

-- ---------- who may call what ----------
-- version 1 functions whose inputs changed
drop function if exists public.upload_game(text, text, text, text, text, text, text, text);
drop function if exists public.student_edit_game(text, text, text, text, text, text, boolean);

revoke all on all functions in schema public from public, anon, authenticated;
grant execute on function
  public.get_state(text), public.get_thumbs(text[]), public.find_games(text), public.lookup_student(text),
  public.student_login(text), public.visitor_create(text, text, text), public.visitor_login(text), public.get_me(uuid),
  public.invest(uuid, text, int), public.withdraw(uuid, text), public.get_investors(text), public.toggle_like(text, text),
  public.upload_game(text, text, text, text, text, text, text, text, boolean),
  public.student_edit_game(text, text, text, text, text, text, boolean, boolean),
  public.admin_check(text), public.admin_get_game(text, text),
  public.admin_edit_game(text, text, text, text, text, text, text, jsonb, text, boolean),
  public.admin_delete_game(text, text), public.admin_import(text, jsonb, boolean),
  public.admin_settings(text, int, int), public.admin_replenish(text, int, text), public.admin_stats(text),
  public.admin_set_code(text, text), public.admin_clear_activity(text), public.admin_visitors(text, boolean), public.admin_reset_coins(text)
to anon, authenticated;
