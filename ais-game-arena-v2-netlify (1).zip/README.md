# AIS Game Arena

Grade 8 game exhibition for Al-Rowad International Schools (Cross Curricular Programme).
Students publish the games they made with Gemini on Netlify. Classmates, parents and visitors play them inside the arena, like them and invest AI Coins. The Rankings page shows the Top 10.

The website is plain HTML and JavaScript with no build step. Shared data (games, sign-ups, coins, likes) lives in a free **Supabase** database. No Google Apps Script is needed.

```
index.html              the page
app.<code>.js           everything the page does (the code in the name changes with each version)
config.js               your Supabase address and public key  ← keep your own copy of this file
assets/                 school and CCP logos
netlify.toml            no build step + long browser caching
supabase/1-setup.sql    creates or upgrades the database (no student data)
```

---

## Upgrading the live arena to version 2 (the relaunch)

Version 2 adds creator earnings, withdrawals, the Profile tab, investor lists, the rules checklist, the parent/visitor lock, a 20 AI Coin minimum and the AIS Game Arena name.
**Nothing below deletes or changes a game that is already in the arena.** Pictures, names and descriptions students have added are kept.

1. **Upgrade the database.** Supabase → **SQL Editor → New query** → paste all of `supabase/1-setup.sql` → **Run**.
   It keeps the student list, games, pictures and admin code.
2. **Add the new games from the Google Form.** New query → paste all of `student-data-part3-new-games.txt` (sent separately because it contains student names and S-numbers; never put it on GitHub) → **Run**.
   It only adds games that aren't in the arena yet, and the result table lists every game as "added" or "already in the arena – kept as it is".
3. **Reset the coins.** Open the arena → settings cog → admin code → **Reset coins → Reset all AI Coins** (tap twice).
   Everyone goes back to their starting AI Coins. Games, pictures, sign-ups and likes stay.
4. **Publish the new website files in ONE deploy** (see "Keeping Netlify costs down" below):
   * Keep your current `config.js`. The one in this folder is a blank template; don't overwrite your working one.
   * Delete the old `app.js` / `app.<code>.js` files from GitHub if they are there.
5. Anyone can open the arena and play games. Only students on the school list can invest. Parents and visitors start **locked**; on the day of the Parent-Teacher Meeting: settings cog → **Open for parents and visitors**.

## How the coins work (version 2)

* Students start with 300 AI Coins, parents and visitors with 100 (the admin can change both).
* The smallest investment is **20 AI Coins**. Students can't invest in their own game.
* **Game makers earn.** When someone invests in a game, the coins are added to the makers' accounts. A pair shares them equally (50 → 25 + 25). An odd coin goes to the first student.
* **Withdrawing.** In **Profile**, an investor can take an investment back out. The **20 AI Coin withdrawal service fee stays in the game**, so the makers keep 20 of it and the investor gets the rest back.
  If the makers had already spent those coins, their balance shows what they owe, and new investments in their game pay it back first.
* **Who invested.** Tap the **Investors** number on any game card or ranking row to see every investor, biggest first. Use this to reward the top investors in the winning games.

## Keeping Netlify costs down

Netlify charges credits for each production deploy (15 credits), for bandwidth (20 credits per GB) and for page requests (2 credits per 10,000). See Netlify's "How credits work" page for current rates.

**Every commit to GitHub starts a new production deploy.** Uploading or editing files one at a time on GitHub can use 15 credits per file. This is the most likely reason credits are running out fast.

* Make all changes, then publish them **in one commit** (drag all the files onto GitHub's upload page together), or
* Deploy without GitHub: Netlify → your site → **Deploys** → drag the whole folder onto the page. That's one deploy.
* While editing a lot, pause automatic deploys: **Site configuration → Build & deploy → Continuous deployment → Stop builds**. Turn it back on when you're ready.
* Check where credits go: Netlify → **Usage & billing**. If the students' own games were published under the school's Netlify team, every time someone plays a game counts there too.

The arena itself is already cheap to load. The logo files and the app file have names that change when their content changes, so browsers keep them for a year (see `netlify.toml`). Returning visitors only re-check the small page. The live numbers come from Supabase, not Netlify.

---

## First-time setup (only for a brand-new copy)

1. **Supabase:** create a free project → SQL Editor → run `supabase/1-setup.sql`, then the private student-data files (`student-data-part1-students.txt`, then `student-data-part2-games.txt`). Never put those on GitHub.
2. Copy the **Project URL** and the **anon public** (or **publishable**) key from Project Settings → API into `config.js`. Never use the `service_role` or `secret` key.
3. **Netlify:** Add new site → Import from GitHub, or drag the folder onto Netlify Drop. Leave the build command empty, publish directory `.`.

## Everyday tasks

| I want to… | Do this |
|---|---|
| Open or lock investing for parents and visitors | Settings cog → **Open for parents and visitors** / **Lock parents and visitors** |
| Add games from a new Google Form export | Upload Game → **Import CSV** → admin code → choose the CSV. Games already in the arena are skipped (same link, same name in the class, or same student with a similar name). |
| Fix a game or add a picture | Pencil on the game card → **Admin**. Students use **Student** with their S-number and must tick the four rules again. |
| Change the starting coins | Settings → **AI Coins for each person** → Save amounts |
| Give everyone more coins | Settings → **Give everyone more AI Coins** |
| Put all coins back to the start | Settings → **Reset coins → Reset all AI Coins** |
| See totals | Settings → **Statistics** |
| Download all results | Supabase → **Table Editor** → `investments`, `earnings`, `games` or `accounts` → **Export → CSV** |
| Add a missing student | Supabase → SQL Editor → `insert into roster (s_number, name, cls) values ('S123456', 'Full Name', '8C');` |

## Good to know

* Free Supabase projects pause after about a week with no visitors. If the arena can't load games, open the Supabase dashboard and click **Restore project**.
* If a particular game shows a blank box inside the arena, that game blocks being shown inside other sites. The **New tab** button still works.
* The admin code is checked in the database. After 8 wrong tries in 10 minutes, admin access pauses for 10 minutes. Change the code from the default.
* Students sign in with their S-number, so anyone who knows a classmate's S-number could use their coins.
